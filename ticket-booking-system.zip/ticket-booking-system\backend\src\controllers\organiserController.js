import prisma from '../config/db.js';

export const organiserController = {
  async getDashboardSummary(req, res, next) {
    try {
      const organiserId = req.user.id;
      const isAdmin = req.user.role === 'ADMIN';

      const eventFilter = isAdmin ? {} : { organiserId };

      const events = await prisma.event.findMany({
        where: eventFilter,
        include: {
          venue: true,
          bookings: {
            where: { status: 'CONFIRMED' },
            include: { bookingSeats: true },
          },
          _count: {
            select: { showSeats: true, waitlistEntries: true },
          },
        },
        orderBy: { eventDate: 'desc' },
      });

      let totalRevenue = 0;
      let totalTicketsSold = 0;
      let totalCapacity = 0;

      const eventSummaries = events.map((event) => {
        const confirmedBookings = event.bookings;
        const ticketsSold = confirmedBookings.reduce((sum, b) => sum + b.bookingSeats.length, 0);
        const revenue = confirmedBookings.reduce((sum, b) => sum + b.totalAmount, 0);
        const capacity = event._count.showSeats;
        const occupancyRate = capacity > 0 ? ((ticketsSold / capacity) * 100).toFixed(1) : '0.0';

        totalRevenue += revenue;
        totalTicketsSold += ticketsSold;
        totalCapacity += capacity;

        return {
          id: event.id,
          title: event.title,
          type: event.type,
          genre: event.genre,
          eventDate: event.eventDate,
          showTime: event.showTime,
          venueName: event.venue?.name,
          totalCapacity: capacity,
          ticketsSold,
          revenue,
          occupancyRate: `${occupancyRate}%`,
          waitlistCount: event._count.waitlistEntries,
          status: event.status,
        };
      });

      const overallOccupancy = totalCapacity > 0 ? ((totalTicketsSold / totalCapacity) * 100).toFixed(1) : '0.0';

      res.json({
        success: true,
        summary: {
          totalEvents: events.length,
          totalTicketsSold,
          totalRevenue,
          overallOccupancy: `${overallOccupancy}%`,
        },
        events: eventSummaries,
      });
    } catch (error) {
      next(error);
    }
  },
};
