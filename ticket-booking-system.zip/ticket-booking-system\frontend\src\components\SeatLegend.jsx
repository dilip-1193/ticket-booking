import React from 'react';

export const SeatLegend = ({ premiumPrice, standardPrice }) => {
  return (
    <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 py-4 px-6 bg-[#052053]/40 border border-[#052053] rounded-2xl text-xs">
      <div className="flex items-center gap-2">
        <div className="w-5 h-5 rounded-md border border-[#5C98A7] bg-[#031435] flex items-center justify-center">
          <span className="w-1.5 h-1.5 rounded-full bg-[#5C98A7]"></span>
        </div>
        <span className="text-[#C2D8DF]">Available</span>
      </div>

      <div className="flex items-center gap-2">
        <div className="w-5 h-5 rounded-md bg-[#044BDD] shadow-glow-blue flex items-center justify-center">
          <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
        </div>
        <span className="text-white font-medium">Selected</span>
      </div>

      <div className="flex items-center gap-2">
        <div className="w-5 h-5 rounded-md border border-[#F5B942] bg-[#F5B942]/20 flex items-center justify-center">
          <span className="w-1.5 h-1.5 rounded-full bg-[#F5B942]"></span>
        </div>
        <span className="text-[#F5B942]">Held / In Checkout</span>
      </div>

      <div className="flex items-center gap-2">
        <div className="w-5 h-5 rounded-md bg-[#1a2333] border border-[#2a374d] opacity-50 flex items-center justify-center">
          <span className="text-[10px] text-gray-500">✕</span>
        </div>
        <span className="text-[#8D98A7]">Booked / Sold Out</span>
      </div>

      {(premiumPrice || standardPrice) && (
        <div className="flex items-center gap-3 pl-4 border-l border-[#052053]">
          {premiumPrice && (
            <span className="px-2 py-0.5 rounded bg-[#044BDD]/20 text-[#5C98A7] font-semibold border border-[#044BDD]/40">
              Premium: ${premiumPrice.toFixed(2)}
            </span>
          )}
          {standardPrice && (
            <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-semibold border border-slate-700">
              Standard: ${standardPrice.toFixed(2)}
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default SeatLegend;
