import express from 'express';
import { eventController } from '../controllers/eventController.js';
import { authenticate, requireRole } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', eventController.getAllEvents);
router.get('/:id', eventController.getEventById);
router.post('/', authenticate, requireRole('ORGANISER', 'ADMIN'), eventController.createEvent);
router.delete('/:id', authenticate, requireRole('ORGANISER', 'ADMIN'), eventController.deleteEvent);

export default router;
