import React, { useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { ShieldCheck, ArrowLeft, CreditCard, Lock, AlertTriangle, CheckCircle2 } from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import HoldTimer from '../components/HoldTimer';

export const CheckoutPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();

  const state = location.state || {};
  const { eventId, event, heldSeatIds = [], expiresAt, selectedSeats = [] } = state;

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!eventId || heldSeatIds.length === 0) {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center">
        <AlertTriangle className="w-12 h-12 text-[#F5B942] mx-auto mb-4" />
        <h2 className="text-xl font-bold text-white mb-2">No Active Seat Hold</h2>
        <p className="text-xs text-[#8D98A7] mb-6">Please select your seats to initiate checkout.</p>
        <Link
          to="/"
          className="px-6 py-3 rounded-xl bg-[#044BDD] text-white text-xs font-bold shadow-cinematic"
        >
          Browse Events
        </Link>
      </div>
    );
  }

  const subtotal = selectedSeats.reduce((sum, s) => sum + (s.price || 0), 0);
  const serviceFee = 2.5;
  const grandTotal = subtotal + serviceFee;

  const handleConfirmBooking = async () => {
    setLoading(true);
    setError('');

    try {
      const res = await api.post('/bookings', {
        eventId,
        showSeatIds: heldSeatIds,
      });

      if (res.data.success) {
        navigate(`/bookings/confirmation/${res.data.booking.id}`, {
          state: { booking: res.data.booking },
        });
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to complete booking. Your hold may have expired.');
    } finally {
      setLoading(false);
    }
  };

  const handleCancelHold = async () => {
    try {
      await api.post(`/seats/${eventId}/release-hold`, {
        showSeatIds: heldSeatIds,
      });
    } catch (e) {
      console.warn('Error releasing hold:', e);
    }
    navigate(`/events/${eventId}/seats`);
  };

  const handleHoldExpired = () => {
    setError('Your temporary seat hold has expired. The seats have been released.');
  };

  return (
    <div className="min-h-screen py-12 px-4 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={handleCancelHold}
            className="flex items-center gap-2 text-xs font-semibold text-[#8D98A7] hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Abandon Hold & Change Seats</span>
          </button>

          <HoldTimer expiresAt={expiresAt} onExpired={handleHoldExpired} />
        </div>

        {error && (
          <div className="p-4 mb-6 rounded-2xl bg-red-950/80 border border-red-500/80 text-red-200 text-xs flex items-center justify-between animate-in fade-in">
            <span>{error}</span>
            <Link
              to={`/events/${eventId}/seats`}
              className="px-3 py-1 bg-red-900 text-white rounded-lg text-[11px] font-bold"
            >
              Back to Seat Map
            </Link>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left Summary */}
          <div className="md:col-span-2 space-y-6">
            {/* Customer Details */}
            <div className="bg-[#052053]/40 border border-[#052053] rounded-3xl p-6">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#044BDD]" /> Customer Information
              </h3>
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-[#8D98A7]">Name</span>
                  <p className="font-semibold text-white mt-1">{user?.name || 'Customer'}</p>
                </div>
                <div>
                  <span className="text-[#8D98A7]">Email (Ticket will be delivered here)</span>
                  <p className="font-semibold text-white mt-1">{user?.email}</p>
                </div>
              </div>
            </div>

            {/* Selected Seats Review */}
            <div className="bg-[#052053]/40 border border-[#052053] rounded-3xl p-6">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
                Selected Seats ({heldSeatIds.length})
              </h3>
              <div className="divide-y divide-[#0a2e73]">
                {selectedSeats.map((seat) => (
                  <div key={seat.id} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-white text-sm mr-2">{seat.seatLabel}</span>
                      <span className="text-[#5C98A7] font-medium">({seat.categoryName})</span>
                    </div>
                    <span className="font-bold text-white">${seat.price?.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Payment Method Notice */}
            <div className="bg-[#031435] border border-[#0a2e73] rounded-3xl p-5 flex items-center gap-3 text-xs text-[#C2D8DF]">
              <Lock className="w-5 h-5 text-[#2ECC71] shrink-0" />
              <div>
                <p className="font-semibold text-white">Instant Confirmation & Verification</p>
                <p className="text-[11px] text-[#8D98A7]">
                  Confirmed tickets generate an encrypted QR code and are dispatched to your registered email immediately.
                </p>
              </div>
            </div>
          </div>

          {/* Right Price Breakdown Card */}
          <div>
            <div className="bg-gradient-to-b from-[#052053] to-[#031435] border border-[#044BDD]/50 rounded-3xl p-6 shadow-2xl sticky top-24">
              <h3 className="text-base font-bold text-white mb-4">Order Summary</h3>

              <div className="space-y-3 text-xs text-[#C2D8DF] pb-4 border-b border-[#0a2e73]">
                <div className="font-bold text-white text-sm truncate">{event?.title}</div>
                <div className="text-[#8D98A7]">{event?.venue?.name} · {event?.showTime}</div>
                <div className="flex justify-between pt-2">
                  <span>Seats Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Booking & Processing</span>
                  <span>${serviceFee.toFixed(2)}</span>
                </div>
              </div>

              <div className="flex justify-between items-center py-4 border-b border-[#0a2e73]">
                <span className="text-sm font-bold text-white">Total Amount</span>
                <span className="text-2xl font-black text-[#2ECC71]">${grandTotal.toFixed(2)}</span>
              </div>

              <button
                onClick={handleConfirmBooking}
                disabled={loading}
                className="w-full py-4 px-4 mt-6 rounded-2xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-extrabold text-sm shadow-cinematic transition-all hover:scale-102 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? 'Confirming Ticket...' : 'Confirm & Issue Ticket'}
              </button>

              <button
                onClick={handleCancelHold}
                className="w-full text-center text-xs text-[#8D98A7] hover:text-white mt-3 transition-colors"
              >
                Cancel Hold
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
