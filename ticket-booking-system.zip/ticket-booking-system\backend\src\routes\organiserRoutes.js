import express from 'express';
import { organiserController } from '../controllers/organiserController.js';
import { authenticate, requireRole } from '../middleware/authMiddleware.js';

const router = express.Router();

router.use(authenticate);
router.use(requireRole('ORGANISER', 'ADMIN'));

router.get('/summary', organiserController.getDashboardSummary);

export default router;
