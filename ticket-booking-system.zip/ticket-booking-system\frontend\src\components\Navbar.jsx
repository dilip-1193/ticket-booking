import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import {
  Film,
  Ticket,
  Clock,
  LayoutDashboard,
  Shield,
  LogOut,
  User,
  Zap,
  Sparkles,
  ChevronDown,
} from 'lucide-react';

export const Navbar = () => {
  const { user, logout, switchDemoUser, isAuthenticated, isAdmin, isOrganiser } = useAuth();
  const { isConnected } = useSocket();
  const navigate = useNavigate();
  const location = useLocation();
  const [showDemoMenu, setShowDemoMenu] = useState(false);

  const isActive = (path) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 bg-[#02050A]/95 backdrop-blur-md border-b border-[#052053] px-4 lg:px-8 py-3">
      {/* Demo Switcher Bar */}
      <div className="max-w-7xl mx-auto flex items-center justify-between text-xs py-1 mb-2 border-b border-[#052053]/50 text-[#8D98A7]">
        <div className="flex items-center gap-2">
          <span className={`inline-block w-2 h-2 rounded-full ${isConnected ? 'bg-[#2ECC71] shadow-glow-green' : 'bg-[#FF5C5C]'}`}></span>
          <span>{isConnected ? 'Real-time WebSocket Connected' : 'Connecting to Real-time Sync...'}</span>
        </div>

        <div className="relative">
          <button
            onClick={() => setShowDemoMenu(!showDemoMenu)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#052053] hover:bg-[#044BDD]/40 text-[#C2D8DF] transition-colors border border-[#044BDD]/30"
          >
            <Zap className="w-3.5 h-3.5 text-[#F5B942]" />
            <span>Switch Demo Role ({user?.role || 'Guest'})</span>
            <ChevronDown className="w-3 h-3" />
          </button>

          {showDemoMenu && (
            <div className="absolute right-0 mt-1 w-56 bg-[#052053] border border-[#044BDD]/40 rounded-lg shadow-2xl py-1 z-50">
              <div className="px-3 py-1.5 text-[10px] uppercase font-bold text-[#8D98A7] tracking-wider border-b border-[#0a2e73]">
                Quick Test Accounts
              </div>
              <button
                onClick={() => { switchDemoUser('CUSTOMER_1'); setShowDemoMenu(false); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#044BDD] text-[#C2D8DF] hover:text-white flex items-center justify-between"
              >
                <span>Alex Mercer</span>
                <span className="text-[10px] bg-blue-900/60 px-1.5 py-0.5 rounded">Customer 1</span>
              </button>
              <button
                onClick={() => { switchDemoUser('CUSTOMER_2'); setShowDemoMenu(false); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#044BDD] text-[#C2D8DF] hover:text-white flex items-center justify-between"
              >
                <span>Sarah Connor</span>
                <span className="text-[10px] bg-blue-900/60 px-1.5 py-0.5 rounded">Customer 2 (Race/Waitlist)</span>
              </button>
              <button
                onClick={() => { switchDemoUser('ORGANISER'); setShowDemoMenu(false); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#044BDD] text-[#C2D8DF] hover:text-white flex items-center justify-between"
              >
                <span>Nolan Events</span>
                <span className="text-[10px] bg-purple-900/60 px-1.5 py-0.5 rounded">Organiser</span>
              </button>
              <button
                onClick={() => { switchDemoUser('ADMIN'); setShowDemoMenu(false); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#044BDD] text-[#C2D8DF] hover:text-white flex items-center justify-between"
              >
                <span>Administrator</span>
                <span className="text-[10px] bg-amber-900/60 px-1.5 py-0.5 rounded">Admin</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#044BDD] to-[#5C98A7] flex items-center justify-center shadow-glow-blue group-hover:scale-105 transition-transform">
            <Film className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="text-lg font-bold text-white tracking-wide flex items-center gap-1.5">
              TICKET<span className="text-[#044BDD]">BOOKING</span>
            </span>
            <span className="text-[10px] text-[#8D98A7] block -mt-1 tracking-widest uppercase">
              Cinemas & Symphonies
            </span>
          </div>
        </Link>

        {/* Center Links */}
        <nav className="hidden md:flex items-center gap-1 bg-[#052053]/40 p-1 rounded-xl border border-[#052053]">
          <Link
            to="/"
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
              isActive('/') ? 'bg-[#044BDD] text-white shadow-cinematic' : 'text-[#C2D8DF] hover:text-white hover:bg-[#052053]'
            }`}
          >
            Explore Events
          </Link>
          <Link
            to="/my-bookings"
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 ${
              isActive('/my-bookings') ? 'bg-[#044BDD] text-white shadow-cinematic' : 'text-[#C2D8DF] hover:text-white hover:bg-[#052053]'
            }`}
          >
            <Ticket className="w-4 h-4" />
            My Bookings
          </Link>
          <Link
            to="/waitlists"
            className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 ${
              isActive('/waitlists') ? 'bg-[#044BDD] text-white shadow-cinematic' : 'text-[#C2D8DF] hover:text-white hover:bg-[#052053]'
            }`}
          >
            <Clock className="w-4 h-4" />
            Waitlists
          </Link>

          {isOrganiser && (
            <Link
              to="/organiser"
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 ${
                isActive('/organiser') ? 'bg-purple-600 text-white' : 'text-purple-300 hover:text-white hover:bg-purple-900/30'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              Organiser Hub
            </Link>
          )}

          {isAdmin && (
            <Link
              to="/admin/venues"
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 ${
                isActive('/admin/venues') ? 'bg-amber-600 text-white' : 'text-amber-300 hover:text-white hover:bg-amber-900/30'
              }`}
            >
              <Shield className="w-4 h-4" />
              Venue Builder
            </Link>
          )}
        </nav>

        {/* Right User State */}
        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <div className="flex items-center gap-3">
              <div className="hidden sm:block text-right">
                <p className="text-sm font-semibold text-white leading-tight">{user.name}</p>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#044BDD]/20 text-[#5C98A7] border border-[#044BDD]/30 font-medium">
                  {user.role}
                </span>
              </div>

              <button
                onClick={logout}
                title="Log Out"
                className="p-2 rounded-xl bg-[#052053] hover:bg-[#FF5C5C]/20 hover:text-[#FF5C5C] text-[#8D98A7] transition-all border border-[#052053]"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                to="/login"
                className="px-4 py-2 rounded-xl text-sm font-medium text-[#C2D8DF] hover:text-white hover:bg-[#052053] transition-colors"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-[#044BDD] hover:bg-[#0337A0] text-white shadow-cinematic transition-all"
              >
                Get Started
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
