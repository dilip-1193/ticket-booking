import prisma from '../src/config/db.js';
import { seatService } from '../src/services/seatService.js';

async function runSeatHoldTest() {
  console.log('\n======================================================');
  console.log('🧪 RUNNING TEST: Seat Hold TTL and Auto-Release Mechanism');
  console.log('======================================================');

  const event = await prisma.event.findFirst({
    include: { showSeats: { where: { status: 'AVAILABLE' } } },
  });

  const targetSeat = event.showSeats[1];
  const user = await prisma.user.findFirst({ where: { role: 'CUSTOMER' } });

  console.log(`🎯 Testing Hold on Seat: ${targetSeat.seatLabel} by ${user.name}`);

  // 1. Place a hold
  const holdRes = await seatService.holdSeats(event.id, [targetSeat.id], user.id);
  console.log(`   ✅ Seat hold placed. Status: ${holdRes.seats[0].status}, Expires: ${holdRes.expiresAt}`);

  // 2. Fetch seats map and verify user-specific held flag
  const seatsList = await seatService.getSeatsForEvent(event.id, user.id);
  const found = seatsList.find((s) => s.id === targetSeat.id);
  if (found.status === 'HELD' && found.isHeldByMe === true) {
    console.log('   ✅ Seat status is HELD and correctly identified as held by the current user.');
  } else {
    throw new Error('   ❌ Seat hold status query failed.');
  }

  // 3. Artificially simulate TTL expiration by moving holdExpiresAt to past
  console.log('   ⏳ Simulating TTL expiration (setting holdExpiresAt to 5 seconds in the past)...');
  await prisma.showSeat.update({
    where: { id: targetSeat.id },
    data: { holdExpiresAt: new Date(Date.now() - 5000) },
  });

  await prisma.seatHold.updateMany({
    where: { showSeatId: targetSeat.id, status: 'ACTIVE' },
    data: { expiresAt: new Date(Date.now() - 5000) },
  });

  // 4. Run background worker auto-release
  console.log('   ⚙️ Triggering background auto-release worker...');
  const releasedCount = await seatService.autoReleaseExpiredHolds();
  console.log(`   ✅ Auto-release worker processed ${releasedCount} expired hold(s).`);

  // 5. Verify database state
  const resetSeat = await prisma.showSeat.findUnique({ where: { id: targetSeat.id } });
  if (resetSeat.status === 'AVAILABLE' && resetSeat.heldByUserId === null) {
    console.log('   ✅ PASS: Seat automatically reverted to AVAILABLE status.');
  } else {
    throw new Error(`   ❌ FAIL: Expected seat status AVAILABLE, got ${resetSeat.status}`);
  }

  console.log('\n🎉 Seat Hold TTL & Auto-Release Test PASSED!\n');
}

runSeatHoldTest()
  .catch((err) => {
    console.error('❌ Test failed:', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
