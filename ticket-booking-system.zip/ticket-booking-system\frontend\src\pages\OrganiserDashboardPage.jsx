import React, { useState, useEffect } from 'react';
import { LayoutDashboard, Plus, DollarSign, Ticket, Users, TrendingUp, Calendar, MapPin, X } from 'lucide-react';
import api from '../services/api';

export const OrganiserDashboardPage = () => {
  const [data, setData] = useState(null);
  const [venues, setVenues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Form states for creating new event
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState('MOVIE');
  const [genre, setGenre] = useState('Sci-Fi / Action');
  const [durationMinutes, setDurationMinutes] = useState(135);
  const [venueId, setVenueId] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [showTime, setShowTime] = useState('19:30');
  const [premiumPrice, setPremiumPrice] = useState(400);
  const [standardPrice, setStandardPrice] = useState(250);
  const [posterUrl, setPosterUrl] = useState('https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&auto=format&fit=crop&q=80');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchDashboard();
    fetchVenues();
  }, []);

  const fetchDashboard = async () => {
    try {
      const res = await api.get('/organiser/summary');
      if (res.data.success) {
        setData(res.data);
      }
    } catch (err) {
      console.error('Error fetching organiser data:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchVenues = async () => {
    try {
      const res = await api.get('/venues');
      if (res.data.success) {
        setVenues(res.data.venues);
        if (res.data.venues.length > 0) {
          setVenueId(res.data.venues[0].id);
        }
      }
    } catch (err) {
      console.error('Error fetching venues:', err);
    }
  };

  const handleCreateEvent = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');

    try {
      const res = await api.post('/events', {
        title,
        description,
        type,
        genre,
        durationMinutes: Number(durationMinutes),
        venueId,
        eventDate,
        showTime,
        premiumPrice: Number(premiumPrice),
        standardPrice: Number(standardPrice),
        posterUrl,
      });

      if (res.data.success) {
        setShowCreateModal(false);
        fetchDashboard();
        // Reset form
        setTitle('');
        setDescription('');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create event.');
    } finally {
      setSubmitting(false);
    }
  };

  const summary = data?.summary || { totalEvents: 0, totalTicketsSold: 0, totalRevenue: 0, overallOccupancy: '0%' };
  const events = data?.events || [];

  return (
    <div className="min-h-screen py-12 px-4 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Organiser Command Center</h1>
            <p className="text-xs text-[#8D98A7] mt-1">Real-time revenue metrics, event listings, and seating analytics.</p>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="px-5 py-3 rounded-2xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-bold text-xs shadow-cinematic transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Event / Showtime</span>
          </button>
        </div>

        {/* Analytics Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-[#052053]/40 border border-[#052053] rounded-3xl p-5">
            <div className="flex items-center justify-between text-[#8D98A7] text-xs">
              <span>Total Revenue</span>
              <DollarSign className="w-4 h-4 text-[#2ECC71]" />
            </div>
            <div className="text-2xl font-black text-white mt-2">${summary.totalRevenue.toFixed(2)}</div>
            <span className="text-[10px] text-[#2ECC71] mt-1 block">Live Gross Receipts</span>
          </div>

          <div className="bg-[#052053]/40 border border-[#052053] rounded-3xl p-5">
            <div className="flex items-center justify-between text-[#8D98A7] text-xs">
              <span>Tickets Sold</span>
              <Ticket className="w-4 h-4 text-[#044BDD]" />
            </div>
            <div className="text-2xl font-black text-white mt-2">{summary.totalTicketsSold}</div>
            <span className="text-[10px] text-[#5C98A7] mt-1 block">Across All Screenings</span>
          </div>

          <div className="bg-[#052053]/40 border border-[#052053] rounded-3xl p-5">
            <div className="flex items-center justify-between text-[#8D98A7] text-xs">
              <span>Average Occupancy</span>
              <TrendingUp className="w-4 h-4 text-[#F5B942]" />
            </div>
            <div className="text-2xl font-black text-white mt-2">{summary.overallOccupancy}</div>
            <span className="text-[10px] text-[#F5B942] mt-1 block">Capacity Utilization</span>
          </div>

          <div className="bg-[#052053]/40 border border-[#052053] rounded-3xl p-5">
            <div className="flex items-center justify-between text-[#8D98A7] text-xs">
              <span>Active Events</span>
              <Calendar className="w-4 h-4 text-purple-400" />
            </div>
            <div className="text-2xl font-black text-white mt-2">{summary.totalEvents}</div>
            <span className="text-[10px] text-purple-300 mt-1 block">Scheduled Shows</span>
          </div>
        </div>

        {/* Events Table */}
        <div className="bg-[#052053]/30 border border-[#052053] rounded-3xl p-6 overflow-hidden">
          <h2 className="text-lg font-bold text-white mb-4">Event Performance & Revenue</h2>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#C2D8DF]">
              <thead className="text-[11px] uppercase text-[#8D98A7] bg-[#02050A]/60 border-b border-[#0a2e73]">
                <tr>
                  <th className="py-3 px-4">Event</th>
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Venue</th>
                  <th className="py-3 px-4">Tickets Sold</th>
                  <th className="py-3 px-4">Occupancy</th>
                  <th className="py-3 px-4">Waitlist</th>
                  <th className="py-3 px-4 text-right">Revenue</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0a2e73]">
                {events.map((ev) => (
                  <tr key={ev.id} className="hover:bg-[#052053]/50 transition-colors">
                    <td className="py-4 px-4 font-bold text-white">
                      {ev.title}
                      <span className="block text-[10px] text-[#5C98A7] font-normal">{ev.genre}</span>
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap">
                      {new Date(ev.eventDate).toLocaleDateString()} at {ev.showTime}
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap">{ev.venueName}</td>
                    <td className="py-4 px-4 whitespace-nowrap">
                      <span className="font-bold text-white">{ev.ticketsSold}</span> / {ev.totalCapacity}
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-[#02050A] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-[#044BDD] rounded-full"
                            style={{ width: ev.occupancyRate }}
                          ></div>
                        </div>
                        <span className="font-semibold">{ev.occupancyRate}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                        {ev.waitlistCount} waiting
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right font-mono font-bold text-[#2ECC71] text-sm">
                      ${ev.revenue.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Create Event Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#052053] border border-[#044BDD]/50 rounded-3xl p-6 sm:p-8 max-w-xl w-full max-h-[90vh] overflow-y-auto relative shadow-2xl">
            <button
              onClick={() => setShowCreateModal(false)}
              className="absolute top-4 right-4 text-[#8D98A7] hover:text-white p-2"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-bold text-white mb-4">Create New Event / Showtime</h3>

            {error && (
              <div className="p-3 mb-4 rounded-xl bg-red-950/70 border border-red-500/70 text-red-200 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleCreateEvent} className="space-y-4 text-xs">
              <div>
                <label className="block text-[#8D98A7] font-semibold mb-1">Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Oppenheimer (70mm IMAX)"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="block text-[#8D98A7] font-semibold mb-1">Description / Synopsis</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Short synopsis..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#8D98A7] font-semibold mb-1">Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                  >
                    <option value="MOVIE">Movie</option>
                    <option value="CONCERT">Concert</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[#8D98A7] font-semibold mb-1">Genre</label>
                  <input
                    type="text"
                    value={genre}
                    onChange={(e) => setGenre(e.target.value)}
                    className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#8D98A7] font-semibold mb-1">Venue</label>
                  <select
                    value={venueId}
                    onChange={(e) => setVenueId(e.target.value)}
                    className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                  >
                    {venues.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.city})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[#8D98A7] font-semibold mb-1">Duration (mins)</label>
                  <input
                    type="number"
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(e.target.value)}
                    className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#8D98A7] font-semibold mb-1">Date</label>
                  <input
                    type="date"
                    required
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                  />
                </div>

                <div>
                  <label className="block text-[#8D98A7] font-semibold mb-1">Showtime</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 19:30"
                    value={showTime}
                    onChange={(e) => setShowTime(e.target.value)}
                    className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#8D98A7] font-semibold mb-1">Premium Seat Price ($)</label>
                  <input
                    type="number"
                    value={premiumPrice}
                    onChange={(e) => setPremiumPrice(e.target.value)}
                    className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                  />
                </div>

                <div>
                  <label className="block text-[#8D98A7] font-semibold mb-1">Standard Seat Price ($)</label>
                  <input
                    type="number"
                    value={standardPrice}
                    onChange={(e) => setStandardPrice(e.target.value)}
                    className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-3.5 px-4 rounded-xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-bold text-sm shadow-cinematic transition-all mt-4 disabled:opacity-50"
              >
                {submitting ? 'Publishing Event...' : 'Publish Event & Initialize Seat Grid'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrganiserDashboardPage;
