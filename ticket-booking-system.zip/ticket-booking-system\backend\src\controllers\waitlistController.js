import { waitlistService } from '../services/waitlistService.js';

export const waitlistController = {
  async joinWaitlist(req, res, next) {
    try {
      const { eventId } = req.params;
      const { seatCategoryName } = req.body;
      const userId = req.user.id;

      if (!seatCategoryName) {
        return res.status(400).json({ success: false, message: 'Seat category name is required' });
      }

      const result = await waitlistService.joinWaitlist(eventId, userId, seatCategoryName);
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  },

  async getMyWaitlists(req, res, next) {
    try {
      const userId = req.user.id;
      const waitlists = await waitlistService.getUserWaitlists(userId);
      res.json({ success: true, waitlists });
    } catch (error) {
      next(error);
    }
  },

  async getOfferDetails(req, res, next) {
    try {
      const { token } = req.params;
      const offer = await waitlistService.getOfferByToken(token);
      res.json({ success: true, offer });
    } catch (error) {
      next(error);
    }
  },

  async claimOffer(req, res, next) {
    try {
      const { token } = req.params;
      const userId = req.user.id;

      const result = await waitlistService.claimWaitlistOffer(token, userId);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
};
