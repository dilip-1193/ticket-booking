import React, { useEffect, useState } from 'react';
import { useParams, useLocation, Link } from 'react-router-dom';
import confetti from 'canvas-confetti';
import { CheckCircle2, Mail, ArrowRight, Home } from 'lucide-react';
import api from '../services/api';
import TicketCard from '../components/TicketCard';

export const BookingConfirmationPage = () => {
  const { id } = useParams();
  const location = useLocation();
  const [booking, setBooking] = useState(location.state?.booking || null);
  const [loading, setLoading] = useState(!location.state?.booking);

  useEffect(() => {
    // Trigger celebration confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#044BDD', '#2ECC71', '#5C98A7', '#FFFFFF'],
      });
    } catch (e) {}

    if (!booking && id) {
      api
        .get(`/bookings/${id}`)
        .then((res) => {
          if (res.data.success) setBooking(res.data.booking);
        })
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [id, booking]);

  if (loading) {
    return (
      <div className="max-w-md mx-auto py-24 text-center">
        <div className="w-12 h-12 border-4 border-[#044BDD] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-sm text-[#8D98A7]">Generating Digital Ticket...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 px-4 lg:px-8">
      <div className="max-w-xl mx-auto space-y-8 text-center">
        {/* Success header */}
        <div className="space-y-3">
          <div className="w-16 h-16 rounded-full bg-[#2ECC71]/20 border-2 border-[#2ECC71] flex items-center justify-center text-[#2ECC71] mx-auto shadow-glow-green animate-in zoom-in duration-300">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Booking Confirmed!
          </h1>

          <div className="flex items-center justify-center gap-2 text-xs text-[#5C98A7] bg-[#052053]/50 py-2 px-4 rounded-xl border border-[#052053] w-fit mx-auto">
            <Mail className="w-4 h-4 text-[#2ECC71]" />
            <span>Digital ticket dispatched to your email address with QR code.</span>
          </div>
        </div>

        {/* Digital Ticket Card */}
        {booking && <TicketCard booking={booking} />}

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
          <Link
            to="/my-bookings"
            className="px-6 py-3 rounded-2xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-bold text-xs shadow-cinematic transition-all flex items-center gap-2"
          >
            <span>View All My Bookings</span>
            <ArrowRight className="w-4 h-4" />
          </Link>

          <Link
            to="/"
            className="px-6 py-3 rounded-2xl bg-[#052053] hover:bg-[#0a2e73] text-[#C2D8DF] font-semibold text-xs transition-colors flex items-center gap-2 border border-[#052053]"
          >
            <Home className="w-4 h-4" />
            <span>Back to Home</span>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default BookingConfirmationPage;
