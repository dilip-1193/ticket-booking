import prisma from '../config/db.js';
import { ENV } from '../config/env.js';
import { broadcastSeatUpdate } from '../sockets/socketHandler.js';
import { logger } from '../utils/logger.js';

export const seatService = {
  /**
   * Fetch all show seats for an event with real-time status and active category metadata
   */
  async getSeatsForEvent(eventId, currentUserId = null) {
    const seats = await prisma.showSeat.findMany({
      where: { eventId },
      orderBy: [{ row: 'asc' }, { number: 'asc' }],
    });

    const now = new Date();

    // Map seats, lazily identifying locally expired holds
    return seats.map((seat) => {
      const isExpiredHold = seat.status === 'HELD' && seat.holdExpiresAt && new Date(seat.holdExpiresAt) < now;
      const effectiveStatus = isExpiredHold ? 'AVAILABLE' : seat.status;
      const isHeldByMe = seat.status === 'HELD' && !isExpiredHold && currentUserId && seat.heldByUserId === currentUserId;

      return {
        id: seat.id,
        seatId: seat.seatId,
        row: seat.row,
        number: seat.number,
        seatLabel: seat.seatLabel,
        categoryName: seat.categoryName,
        price: seat.price,
        status: effectiveStatus,
        isHeldByMe: Boolean(isHeldByMe),
        holdExpiresAt: effectiveStatus === 'HELD' ? seat.holdExpiresAt : null,
      };
    });
  },

  /**
   * Concurrency-safe seat hold acquisition using atomic database transactions.
   * If two requests attempt to hold the same seat simultaneously, only one succeeds;
   * the other receives a 409 Conflict.
   */
  async holdSeats(eventId, showSeatIds, userId) {
    if (!showSeatIds || !Array.isArray(showSeatIds) || showSeatIds.length === 0) {
      const err = new Error('No seats specified to hold');
      err.statusCode = 400;
      throw err;
    }

    const ttlMinutes = ENV.SEAT_HOLD_TTL_MINUTES || 10;
    const expiresAt = new Date(Date.now() + ttlMinutes * 60 * 1000);

    // Execute atomic interactive transaction
    const result = await prisma.$transaction(async (tx) => {
      // 1. Fetch current seat records
      const seats = await tx.showSeat.findMany({
        where: {
          id: { in: showSeatIds },
          eventId,
        },
      });

      if (seats.length !== showSeatIds.length) {
        const err = new Error('One or more requested seats were not found for this event');
        err.statusCode = 404;
        throw err;
      }

      const now = new Date();

      // 2. Validate that each seat is truly available (or has an already expired hold)
      for (const seat of seats) {
        const isHoldExpired = seat.status === 'HELD' && seat.holdExpiresAt && new Date(seat.holdExpiresAt) < now;
        const isAlreadyHeldByCurrentUser = seat.status === 'HELD' && !isHoldExpired && seat.heldByUserId === userId;

        if (seat.status === 'BOOKED') {
          const err = new Error(`Seat ${seat.seatLabel} is already booked.`);
          err.statusCode = 409;
          throw err;
        }

        if (seat.status === 'OFFERED') {
          const err = new Error(`Seat ${seat.seatLabel} is currently reserved for a waitlisted customer.`);
          err.statusCode = 409;
          throw err;
        }

        if (seat.status === 'HELD' && !isHoldExpired && !isAlreadyHeldByCurrentUser) {
          const err = new Error(`Seat ${seat.seatLabel} is currently held by another customer.`);
          err.statusCode = 409;
          throw err;
        }
      }

      // 3. Mark previous active holds for this user & seats as converted/replaced
      await tx.seatHold.updateMany({
        where: {
          eventId,
          userId,
          showSeatId: { in: showSeatIds },
          status: 'ACTIVE',
        },
        data: { status: 'EXPIRED' },
      });

      // 4. Update each ShowSeat to HELD with atomic version bump
      const updatedSeats = [];
      for (const seat of seats) {
        const updated = await tx.showSeat.update({
          where: { id: seat.id },
          data: {
            status: 'HELD',
            heldByUserId: userId,
            holdExpiresAt: expiresAt,
            version: { increment: 1 },
          },
        });
        updatedSeats.push(updated);

        // Create SeatHold audit record
        await tx.seatHold.create({
          data: {
            eventId,
            userId,
            showSeatId: seat.id,
            status: 'ACTIVE',
            expiresAt,
          },
        });
      }

      return { updatedSeats, expiresAt };
    });

    // 5. Broadcast real-time Socket.IO update to all clients viewing this event
    broadcastSeatUpdate(eventId, {
      type: 'SEAT_HELD',
      eventId,
      seatIds: showSeatIds,
      heldByUserId: userId,
      expiresAt: result.expiresAt,
    });

    logger.info(`User ${userId} successfully held seats [${result.updatedSeats.map((s) => s.seatLabel).join(', ')}] until ${result.expiresAt.toISOString()}`);

    return {
      success: true,
      message: 'Seats held successfully',
      seats: result.updatedSeats,
      expiresAt: result.expiresAt,
      ttlMinutes,
    };
  },

  /**
   * Release active seat holds for a user on an event
   */
  async releaseSeatHolds(eventId, showSeatIds, userId) {
    const result = await prisma.$transaction(async (tx) => {
      const seatsToRelease = await tx.showSeat.findMany({
        where: {
          eventId,
          id: { in: showSeatIds },
          heldByUserId: userId,
          status: 'HELD',
        },
      });

      if (seatsToRelease.length === 0) {
        return [];
      }

      const ids = seatsToRelease.map((s) => s.id);

      await tx.showSeat.updateMany({
        where: { id: { in: ids } },
        data: {
          status: 'AVAILABLE',
          heldByUserId: null,
          holdExpiresAt: null,
          version: { increment: 1 },
        },
      });

      await tx.seatHold.updateMany({
        where: {
          eventId,
          userId,
          showSeatId: { in: ids },
          status: 'ACTIVE',
        },
        data: { status: 'RELEASED' },
      });

      return seatsToRelease;
    });

    if (result.length > 0) {
      broadcastSeatUpdate(eventId, {
        type: 'SEAT_RELEASED',
        eventId,
        seatIds: result.map((s) => s.id),
      });
    }

    return { success: true, releasedSeats: result };
  },

  /**
   * Background TTL auto-release worker logic
   */
  async autoReleaseExpiredHolds() {
    const now = new Date();

    try {
      // Find show seats where hold has expired
      const expiredSeats = await prisma.showSeat.findMany({
        where: {
          status: 'HELD',
          holdExpiresAt: { lte: now },
        },
      });

      if (expiredSeats.length === 0) {
        return 0;
      }

      const seatIds = expiredSeats.map((s) => s.id);

      await prisma.$transaction(async (tx) => {
        // Reset seats to AVAILABLE
        await tx.showSeat.updateMany({
          where: { id: { in: seatIds } },
          data: {
            status: 'AVAILABLE',
            heldByUserId: null,
            holdExpiresAt: null,
            version: { increment: 1 },
          },
        });

        // Mark holds as EXPIRED
        await tx.seatHold.updateMany({
          where: {
            showSeatId: { in: seatIds },
            status: 'ACTIVE',
          },
          data: { status: 'EXPIRED' },
        });
      });

      // Group by eventId to broadcast
      const eventGroups = {};
      for (const seat of expiredSeats) {
        if (!eventGroups[seat.eventId]) eventGroups[seat.eventId] = [];
        eventGroups[seat.eventId].push(seat.id);
      }

      for (const [eventId, ids] of Object.entries(eventGroups)) {
        broadcastSeatUpdate(eventId, {
          type: 'SEAT_RELEASED',
          eventId,
          seatIds: ids,
          reason: 'TTL_EXPIRED',
        });
        logger.info(`Auto-released ${ids.length} expired seat hold(s) for event ${eventId}`);
      }

      return expiredSeats.length;
    } catch (error) {
      logger.error('Error during autoReleaseExpiredHolds:', error);
      return 0;
    }
  },
};
