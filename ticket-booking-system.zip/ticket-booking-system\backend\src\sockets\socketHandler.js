import { logger } from '../utils/logger.js';

let ioInstance = null;

export const initSocket = (io) => {
  ioInstance = io;

  io.on('connection', (socket) => {
    logger.debug(`Socket client connected: ${socket.id}`);

    // Join show/event room for real-time seat status updates
    socket.on('join_event', (eventId) => {
      if (eventId) {
        socket.join(`event:${eventId}`);
        logger.debug(`Socket ${socket.id} joined event room: event:${eventId}`);
      }
    });

    // Leave show room
    socket.on('leave_event', (eventId) => {
      if (eventId) {
        socket.leave(`event:${eventId}`);
        logger.debug(`Socket ${socket.id} left event room: event:${eventId}`);
      }
    });

    // Join personal user room for private waitlist offer and booking events
    socket.on('join_user', (userId) => {
      if (userId) {
        socket.join(`user:${userId}`);
        logger.debug(`Socket ${socket.id} joined user room: user:${userId}`);
      }
    });

    socket.on('disconnect', () => {
      logger.debug(`Socket client disconnected: ${socket.id}`);
    });
  });
};

export const getIO = () => {
  return ioInstance;
};

/**
 * Real-time event broadcasters
 */
export const broadcastSeatUpdate = (eventId, payload) => {
  if (ioInstance) {
    ioInstance.to(`event:${eventId}`).emit('seat_status_changed', payload);
  }
};

export const broadcastWaitlistOffer = (userId, payload) => {
  if (ioInstance) {
    ioInstance.to(`user:${userId}`).emit('waitlist_offer_received', payload);
  }
};
