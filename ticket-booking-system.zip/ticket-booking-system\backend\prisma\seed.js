import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import QRCode from 'qrcode';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seeding...');

  // Clear existing data safely
  await prisma.ticket.deleteMany();
  await prisma.bookingSeat.deleteMany();
  await prisma.booking.deleteMany();
  await prisma.waitlistOffer.deleteMany();
  await prisma.waitlistEntry.deleteMany();
  await prisma.seatHold.deleteMany();
  await prisma.showSeat.deleteMany();
  await prisma.seat.deleteMany();
  await prisma.seatCategory.deleteMany();
  await prisma.event.deleteMany();
  await prisma.venue.deleteMany();
  await prisma.user.deleteMany();

  console.log('🧹 Cleaned existing records.');

  // 1. Create Users
  const passwordHash = await bcrypt.hash('password123', 10);
  const adminHash = await bcrypt.hash('admin123', 10);
  const orgHash = await bcrypt.hash('org123', 10);
  const custHash = await bcrypt.hash('cust123', 10);

  const adminUser = await prisma.user.create({
    data: {
      name: 'System Administrator',
      email: 'admin@tickets.com',
      password: adminHash,
      role: 'ADMIN',
    },
  });

  const organiserUser = await prisma.user.create({
    data: {
      name: 'Christopher Nolan Events',
      email: 'organiser@cinema.com',
      password: orgHash,
      role: 'ORGANISER',
    },
  });

  const customer1 = await prisma.user.create({
    data: {
      name: 'Alex Mercer',
      email: 'customer1@test.com',
      password: custHash,
      role: 'CUSTOMER',
    },
  });

  const customer2 = await prisma.user.create({
    data: {
      name: 'Sarah Connor',
      email: 'customer2@test.com',
      password: custHash,
      role: 'CUSTOMER',
    },
  });

  const customer3 = await prisma.user.create({
    data: {
      name: 'David Bowman',
      email: 'customer3@test.com',
      password: custHash,
      role: 'CUSTOMER',
    },
  });

  console.log('👤 Created users (Admin, Organiser, Customers).');

  // 2. Create Venues with Seat Categories and Seats
  // Venue 1: IMAX Grand Theater (6 rows A-F x 10 seats)
  const venue1 = await prisma.venue.create({
    data: {
      name: 'IMAX Grand Theater',
      city: 'San Francisco',
      address: '750 Howard St, San Francisco, CA',
      totalRows: 6,
      seatsPerRow: 10,
    },
  });

  const premCat1 = await prisma.seatCategory.create({
    data: {
      venueId: venue1.id,
      name: 'Premium',
      color: '#044BDD',
      basePriceMultiplier: 1.6,
    },
  });

  const stdCat1 = await prisma.seatCategory.create({
    data: {
      venueId: venue1.id,
      name: 'Standard',
      color: '#5C98A7',
      basePriceMultiplier: 1.0,
    },
  });

  const venue1Seats = [];
  for (let r = 0; r < 6; r++) {
    const rowLetter = String.fromCharCode(65 + r); // A to F
    const categoryId = r < 2 ? premCat1.id : stdCat1.id; // Rows A-B: Premium, C-F: Standard
    for (let c = 1; c <= 10; c++) {
      const s = await prisma.seat.create({
        data: {
          venueId: venue1.id,
          row: rowLetter,
          number: c,
          seatLabel: `${rowLetter}${c}`,
          categoryId,
        },
      });
      venue1Seats.push({ ...s, categoryName: r < 2 ? 'Premium' : 'Standard' });
    }
  }

  // Venue 2: Metropolis Symphony Hall
  const venue2 = await prisma.venue.create({
    data: {
      name: 'Metropolis Symphony Hall',
      city: 'New York',
      address: '150 W 65th St, New York, NY',
      totalRows: 6,
      seatsPerRow: 8,
    },
  });

  const premCat2 = await prisma.seatCategory.create({
    data: {
      venueId: venue2.id,
      name: 'Premium',
      color: '#044BDD',
      basePriceMultiplier: 1.5,
    },
  });

  const stdCat2 = await prisma.seatCategory.create({
    data: {
      venueId: venue2.id,
      name: 'Standard',
      color: '#5C98A7',
      basePriceMultiplier: 1.0,
    },
  });

  const venue2Seats = [];
  for (let r = 0; r < 6; r++) {
    const rowLetter = String.fromCharCode(65 + r);
    const categoryId = r < 2 ? premCat2.id : stdCat2.id;
    for (let c = 1; c <= 8; c++) {
      const s = await prisma.seat.create({
        data: {
          venueId: venue2.id,
          row: rowLetter,
          number: c,
          seatLabel: `${rowLetter}${c}`,
          categoryId,
        },
      });
      venue2Seats.push({ ...s, categoryName: r < 2 ? 'Premium' : 'Standard' });
    }
  }

  console.log('🏛️ Created Venues, Seat Categories, and Seating Grids.');

  // 3. Create Events
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(19, 30, 0, 0);

  const nextWeek = new Date();
  nextWeek.setDate(nextWeek.getDate() + 5);
  nextWeek.setHours(20, 0, 0, 0);

  const weekend = new Date();
  weekend.setDate(weekend.getDate() + 3);
  weekend.setHours(18, 0, 0, 0);

  const event1 = await prisma.event.create({
    data: {
      title: 'Interstellar: 10th Anniversary IMAX',
      description:
        'Experience Christopher Nolan’s breathtaking sci-fi masterpiece in full 70mm IMAX format with remastered sound design and visual effects.',
      type: 'MOVIE',
      genre: 'Sci-Fi / Drama',
      durationMinutes: 169,
      posterUrl: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=800&auto=format&fit=crop&q=80',
      bannerUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1600&auto=format&fit=crop&q=80',
      venueId: venue1.id,
      organiserId: organiserUser.id,
      eventDate: tomorrow,
      showTime: '19:30',
      premiumPrice: 450.0,
      standardPrice: 250.0,
      status: 'UPCOMING',
    },
  });

  const event2 = await prisma.event.create({
    data: {
      title: 'Hans Zimmer: The Symphonic Odyssey',
      description:
        'A magnificent live orchestral performance featuring iconic film scores from Inception, Gladiator, The Dark Knight, Dune, and Interstellar.',
      type: 'CONCERT',
      genre: 'Classical / Film Score',
      durationMinutes: 145,
      posterUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=80',
      bannerUrl: 'https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=1600&auto=format&fit=crop&q=80',
      venueId: venue2.id,
      organiserId: organiserUser.id,
      eventDate: nextWeek,
      showTime: '20:00',
      premiumPrice: 600.0,
      standardPrice: 350.0,
      status: 'UPCOMING',
    },
  });

  const event3 = await prisma.event.create({
    data: {
      title: 'Dune: Part Two (70mm Experience)',
      description:
        'Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.',
      type: 'MOVIE',
      genre: 'Action / Adventure',
      durationMinutes: 166,
      posterUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&auto=format&fit=crop&q=80',
      bannerUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1600&auto=format&fit=crop&q=80',
      venueId: venue1.id,
      organiserId: organiserUser.id,
      eventDate: weekend,
      showTime: '18:00',
      premiumPrice: 400.0,
      standardPrice: 220.0,
      status: 'UPCOMING',
    },
  });

  console.log('🎬 Created Events.');

  // 4. Create ShowSeats for Event 1
  for (const seat of venue1Seats) {
    const isPremium = seat.categoryName === 'Premium';
    await prisma.showSeat.create({
      data: {
        eventId: event1.id,
        seatId: seat.id,
        row: seat.row,
        number: seat.number,
        seatLabel: seat.seatLabel,
        categoryName: seat.categoryName,
        price: isPremium ? event1.premiumPrice : event1.standardPrice,
        status: 'AVAILABLE',
      },
    });
  }

  // ShowSeats for Event 2
  for (const seat of venue2Seats) {
    const isPremium = seat.categoryName === 'Premium';
    await prisma.showSeat.create({
      data: {
        eventId: event2.id,
        seatId: seat.id,
        row: seat.row,
        number: seat.number,
        seatLabel: seat.seatLabel,
        categoryName: seat.categoryName,
        price: isPremium ? event2.premiumPrice : event2.standardPrice,
        status: 'AVAILABLE',
      },
    });
  }

  // ShowSeats for Event 3
  for (const seat of venue1Seats) {
    const isPremium = seat.categoryName === 'Premium';
    await prisma.showSeat.create({
      data: {
        eventId: event3.id,
        seatId: seat.id,
        row: seat.row,
        number: seat.number,
        seatLabel: seat.seatLabel,
        categoryName: seat.categoryName,
        price: isPremium ? event3.premiumPrice : event3.standardPrice,
        status: 'AVAILABLE',
      },
    });
  }

  console.log('🎟️ Created ShowSeats.');

  // 5. Seed a sample confirmed booking for Customer 1 on Event 1 (Seats A5, A6)
  const bookedSeatA5 = await prisma.showSeat.findFirst({
    where: { eventId: event1.id, seatLabel: 'A5' },
  });
  const bookedSeatA6 = await prisma.showSeat.findFirst({
    where: { eventId: event1.id, seatLabel: 'A6' },
  });

  if (bookedSeatA5 && bookedSeatA6) {
    await prisma.showSeat.updateMany({
      where: { id: { in: [bookedSeatA5.id, bookedSeatA6.id] } },
      data: { status: 'BOOKED' },
    });

    const bookingRef = 'TBS-2026-X8Y7Z2';
    const qrPayload = JSON.stringify({
      ref: bookingRef,
      event: event1.title,
      seats: ['A5', 'A6'],
      user: customer1.name,
      ts: Date.now(),
    });
    const qrDataUrl = await QRCode.toDataURL(qrPayload);

    const booking = await prisma.booking.create({
      data: {
        bookingReference: bookingRef,
        userId: customer1.id,
        eventId: event1.id,
        totalAmount: bookedSeatA5.price + bookedSeatA6.price,
        status: 'CONFIRMED',
        qrCodeData: qrDataUrl,
        bookingSeats: {
          create: [
            {
              showSeatId: bookedSeatA5.id,
              seatLabel: 'A5',
              categoryName: 'Premium',
              price: bookedSeatA5.price,
            },
            {
              showSeatId: bookedSeatA6.id,
              seatLabel: 'A6',
              categoryName: 'Premium',
              price: bookedSeatA6.price,
            },
          ],
        },
        tickets: {
          create: [
            { ticketNumber: `TKT-${bookingRef}-1` },
            { ticketNumber: `TKT-${bookingRef}-2` },
          ],
        },
      },
    });

    console.log(`🎫 Created initial confirmed booking: ${booking.bookingReference}`);
  }

  // 6. Seed a waitlist entry for Customer 3 on Event 1
  await prisma.waitlistEntry.create({
    data: {
      eventId: event1.id,
      userId: customer3.id,
      seatCategoryName: 'Premium',
      position: 1,
      status: 'WAITING',
    },
  });

  console.log('📋 Created initial Waitlist entry.');
  console.log('✅ Seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
