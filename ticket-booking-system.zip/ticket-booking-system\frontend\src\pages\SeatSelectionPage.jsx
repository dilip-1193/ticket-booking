import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, ShieldCheck, AlertCircle, Sparkles, RefreshCw } from 'lucide-react';
import api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import SeatMap from '../components/SeatMap';
import SeatLegend from '../components/SeatLegend';
import HoldTimer from '../components/HoldTimer';
import WaitlistModal from '../components/WaitlistModal';

export const SeatSelectionPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();

  const [event, setEvent] = useState(null);
  const [seats, setSeats] = useState([]);
  const [selectedSeatIds, setSelectedSeatIds] = useState([]);
  const [activeHoldExpiresAt, setActiveHoldExpiresAt] = useState(null);
  const [loading, setLoading] = useState(true);
  const [holding, setHolding] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showWaitlistModal, setShowWaitlistModal] = useState(false);

  // Load event details & seats
  const fetchSeats = useCallback(async () => {
    try {
      const [eventRes, seatsRes] = await Promise.all([
        api.get(`/events/${id}`),
        api.get(`/seats/${id}/seats`),
      ]);

      if (eventRes.data.success) setEvent(eventRes.data.event);
      if (seatsRes.data.success) {
        setSeats(seatsRes.data.seats);

        // Check if user has active hold
        const myHeldSeats = seatsRes.data.seats.filter((s) => s.isHeldByMe && s.holdExpiresAt);
        if (myHeldSeats.length > 0) {
          setSelectedSeatIds(myHeldSeats.map((s) => s.id));
          setActiveHoldExpiresAt(myHeldSeats[0].holdExpiresAt);
        }
      }
    } catch (err) {
      console.error('Error fetching seats:', err);
      setErrorMessage('Could not load seat map. Please check connection.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchSeats();

    // Join Socket.IO event room for live seat status broadcasting
    socket.emit('join_event', id);

    const handleSeatStatusChanged = (payload) => {
      console.log('📡 Real-time seat update received:', payload);
      // Refresh seats immediately
      fetchSeats();
    };

    socket.on('seat_status_changed', handleSeatStatusChanged);

    return () => {
      socket.emit('leave_event', id);
      socket.off('seat_status_changed', handleSeatStatusChanged);
    };
  }, [id, fetchSeats]);

  // Toggle seat selection
  const handleToggleSeat = (seat) => {
    setErrorMessage('');
    if (selectedSeatIds.includes(seat.id)) {
      setSelectedSeatIds((prev) => prev.filter((sId) => sId !== seat.id));
    } else {
      // Max 6 seats per booking
      if (selectedSeatIds.length >= 6) {
        setErrorMessage('You can select up to 6 seats per booking.');
        return;
      }
      setSelectedSeatIds((prev) => [...prev, seat.id]);
    }
  };

  // Place concurrency-safe hold and proceed to checkout
  const handleProceedToHold = async () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { returnUrl: `/events/${id}/seats` } });
      return;
    }

    if (selectedSeatIds.length === 0) {
      setErrorMessage('Please select at least one seat to continue.');
      return;
    }

    setHolding(true);
    setErrorMessage('');

    try {
      const res = await api.post(`/seats/${id}/hold`, {
        showSeatIds: selectedSeatIds,
      });

      if (res.data.success) {
        setActiveHoldExpiresAt(res.data.expiresAt);
        // Navigate to Checkout with hold details in state
        navigate('/checkout', {
          state: {
            eventId: id,
            event,
            heldSeatIds: selectedSeatIds,
            expiresAt: res.data.expiresAt,
            selectedSeats: res.data.seats,
          },
        });
      }
    } catch (err) {
      const msg = err.response?.data?.message || 'Failed to hold selected seats. Another user may have just acquired them.';
      setErrorMessage(msg);
      // Refresh seat map to reflect newest state
      fetchSeats();
    } finally {
      setHolding(false);
    }
  };

  const handleHoldExpired = () => {
    setActiveHoldExpiresAt(null);
    setSelectedSeatIds([]);
    setErrorMessage('Your temporary seat hold has expired. Please select your seats again.');
    fetchSeats();
  };

  // Calculate selected subtotal
  const selectedSeatsList = seats.filter((s) => selectedSeatIds.includes(s.id));
  const subtotal = selectedSeatsList.reduce((sum, s) => sum + s.price, 0);

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-20 text-center">
        <RefreshCw className="w-8 h-8 text-[#044BDD] animate-spin mx-auto mb-4" />
        <p className="text-sm text-[#8D98A7]">Loading Real-Time Seating Layout...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-28">
      {/* Header bar */}
      <div className="bg-[#052053]/40 border-b border-[#052053] px-4 lg:px-8 py-4">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Link
              to={`/events/${id}`}
              className="p-2 rounded-xl bg-[#031435] hover:bg-[#044BDD] text-[#C2D8DF] hover:text-white transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </Link>
            <div>
              <h1 className="text-lg font-bold text-white leading-tight">{event?.title}</h1>
              <p className="text-xs text-[#5C98A7]">
                {event?.venue?.name} · {event?.showTime} · Real-time Seat Map
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {activeHoldExpiresAt && (
              <HoldTimer expiresAt={activeHoldExpiresAt} onExpired={handleHoldExpired} />
            )}

            <button
              onClick={() => setShowWaitlistModal(true)}
              className="px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold"
            >
              Join Waitlist
            </button>
          </div>
        </div>
      </div>

      {/* Main Seat Map Area */}
      <div className="max-w-5xl mx-auto px-4 mt-6">
        {errorMessage && (
          <div className="p-4 mb-6 rounded-2xl bg-red-950/70 border border-red-500/80 text-red-200 text-xs flex items-center gap-2.5 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="bg-[#052053]/30 border border-[#052053] rounded-3xl p-6 sm:p-8 backdrop-blur-sm">
          {/* Seat Map visual */}
          <SeatMap
            seats={seats}
            selectedSeatIds={selectedSeatIds}
            onToggleSeat={handleToggleSeat}
          />

          {/* Seat Legend */}
          <div className="mt-8">
            <SeatLegend
              premiumPrice={event?.premiumPrice}
              standardPrice={event?.standardPrice}
            />
          </div>
        </div>
      </div>

      {/* Fixed Bottom Checkout Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#02050A]/95 border-t border-[#052053] backdrop-blur-lg px-4 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          <div>
            <span className="text-[11px] text-[#8D98A7] block">
              {selectedSeatIds.length === 0
                ? 'Select seats from map'
                : `${selectedSeatIds.length} Seat(s) Selected: ${selectedSeatsList.map((s) => s.seatLabel).join(', ')}`}
            </span>
            <span className="text-xl font-extrabold text-white">
              ${subtotal.toFixed(2)}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleProceedToHold}
              disabled={selectedSeatIds.length === 0 || holding}
              className="px-6 sm:px-8 py-3.5 rounded-2xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-extrabold text-sm shadow-cinematic transition-all hover:scale-105 disabled:opacity-40 disabled:hover:scale-100 flex items-center gap-2"
            >
              <span>{holding ? 'Placing Hold...' : 'Hold & Proceed to Checkout'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Waitlist Modal */}
      <WaitlistModal
        event={event}
        isOpen={showWaitlistModal}
        onClose={() => setShowWaitlistModal(false)}
      />
    </div>
  );
};

export default SeatSelectionPage;
