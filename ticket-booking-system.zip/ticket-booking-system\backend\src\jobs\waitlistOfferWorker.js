import { waitlistService } from '../services/waitlistService.js';
import { logger } from '../utils/logger.js';

let intervalHandle = null;

export const startWaitlistOfferWorker = (intervalMs = 5000) => {
  logger.info(`Starting Waitlist Offer Expiration Worker (Interval: ${intervalMs}ms)...`);

  intervalHandle = setInterval(async () => {
    try {
      await waitlistService.processExpiredOffers();
    } catch (error) {
      logger.error('Error in Waitlist Offer Worker loop:', error);
    }
  }, intervalMs);
};

export const stopWaitlistOfferWorker = () => {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
    logger.info('Stopped Waitlist Offer Worker');
  }
};
