import React from 'react';
import { QrCode, Calendar, Clock, MapPin, Ticket as TicketIcon, CheckCircle2 } from 'lucide-react';

export const TicketCard = ({ booking }) => {
  if (!booking) return null;

  const event = booking.event || {};
  const seats = booking.bookingSeats || [];
  const seatLabels = seats.map((s) => s.seatLabel).join(', ');

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="w-full max-w-md mx-auto relative bg-[#052053] border border-[#044BDD]/40 rounded-3xl overflow-hidden shadow-2xl transition-all hover:border-[#044BDD]">
      {/* Top Header */}
      <div className="bg-gradient-to-r from-[#044BDD] to-[#0337A0] p-6 text-white text-center relative">
        <div className="flex items-center justify-between text-xs font-semibold text-blue-200 uppercase tracking-widest mb-1">
          <span>Digital Admission</span>
          <span className="flex items-center gap-1 text-[#2ECC71]">
            <CheckCircle2 className="w-3.5 h-3.5" />
            {booking.status}
          </span>
        </div>
        <h3 className="text-xl font-extrabold tracking-wide text-white">{event.title || 'Movie / Concert'}</h3>
        <p className="text-xs text-blue-200 mt-1 font-medium">{event.genre} · {event.durationMinutes || 120} min</p>
      </div>

      {/* Middle Details */}
      <div className="p-6 space-y-4 text-sm text-[#C2D8DF] relative">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <span className="text-[11px] text-[#8D98A7] uppercase font-bold flex items-center gap-1">
              <Calendar className="w-3 h-3 text-[#5C98A7]" /> Date
            </span>
            <p className="font-semibold text-white mt-0.5">
              {event.eventDate ? new Date(event.eventDate).toLocaleDateString() : 'Today'}
            </p>
          </div>

          <div>
            <span className="text-[11px] text-[#8D98A7] uppercase font-bold flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#5C98A7]" /> Showtime
            </span>
            <p className="font-semibold text-white mt-0.5">{event.showTime || '19:30'}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2 border-t border-[#0a2e73]">
          <div>
            <span className="text-[11px] text-[#8D98A7] uppercase font-bold flex items-center gap-1">
              <MapPin className="w-3 h-3 text-[#5C98A7]" /> Venue
            </span>
            <p className="font-semibold text-white mt-0.5 text-xs truncate">
              {event.venue?.name || 'Grand Theater'}
            </p>
          </div>

          <div>
            <span className="text-[11px] text-[#8D98A7] uppercase font-bold flex items-center gap-1">
              <TicketIcon className="w-3 h-3 text-[#5C98A7]" /> Seats
            </span>
            <p className="font-bold text-[#2ECC71] text-base mt-0.5">{seatLabels || 'A1'}</p>
          </div>
        </div>

        {/* Perforated Notches */}
        <div className="ticket-notch-left"></div>
        <div className="ticket-notch-right"></div>
        <div className="border-b border-dashed border-[#0a2e73] my-4"></div>

        {/* QR Code Section */}
        <div className="flex flex-col items-center justify-center p-3 bg-white rounded-2xl">
          {booking.qrCodeData ? (
            <img
              src={booking.qrCodeData}
              alt="Admission QR Code"
              className="w-44 h-44 object-contain rounded-lg"
            />
          ) : (
            <div className="w-44 h-44 bg-gray-100 flex items-center justify-center rounded-lg text-gray-500">
              <QrCode className="w-16 h-16 text-gray-400" />
            </div>
          )}
          <p className="font-mono text-xs font-bold text-gray-800 mt-2 tracking-widest">
            {booking.bookingReference}
          </p>
          <span className="text-[10px] text-gray-500">Scan at entrance for validation</span>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-[#031435] p-4 text-center border-t border-[#0a2e73]">
        <button
          onClick={handlePrint}
          className="text-xs text-[#5C98A7] hover:text-white transition-colors underline font-medium"
        >
          Print / Download Ticket PDF
        </button>
      </div>
    </div>
  );
};

export default TicketCard;
