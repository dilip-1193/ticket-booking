import React, { useState, useEffect } from 'react';
import { Shield, Building2, MapPin, Grid, Trash2 } from 'lucide-react';
import api from '../services/api';
import VenueBuilder from '../components/VenueBuilder';

export const AdminVenuesPage = () => {
  const [venues, setVenues] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchVenues();
  }, []);

  const fetchVenues = async () => {
    try {
      const res = await api.get('/venues');
      if (res.data.success) {
        setVenues(res.data.venues);
      }
    } catch (err) {
      console.error('Error fetching venues:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleVenueCreated = (newVenue) => {
    fetchVenues();
  };

  const handleDeleteVenue = async (id) => {
    if (!window.confirm('Are you sure you want to delete this venue? All associated seat maps will be removed.')) return;
    try {
      await api.delete(`/venues/${id}`);
      fetchVenues();
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete venue.');
    }
  };

  return (
    <div className="min-h-screen py-12 px-4 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-10">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-[#F5B942] uppercase tracking-wider mb-1">
            <Shield className="w-4 h-4" />
            <span>Administrator Control Center</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">Venue & Seating Layout Manager</h1>
          <p className="text-xs text-[#8D98A7] mt-1">
            Build custom theater architectures, define rows and columns, configure category tiers, and manage auditorium grids.
          </p>
        </div>

        {/* Venue Builder Form */}
        <VenueBuilder onVenueCreated={handleVenueCreated} />

        {/* Existing Venues List */}
        <div className="space-y-4">
          <h2 className="text-lg font-bold text-white">Active Venues & Auditoriums ({venues.length})</h2>

          {loading ? (
            <div className="h-40 bg-[#052053]/40 rounded-3xl animate-pulse"></div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {venues.map((venue) => (
                <div
                  key={venue.id}
                  className="bg-[#052053]/40 border border-[#052053] hover:border-[#044BDD] rounded-3xl p-6 transition-all relative group flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="w-8 h-8 rounded-xl bg-[#044BDD]/20 text-[#044BDD] flex items-center justify-center">
                        <Building2 className="w-4 h-4" />
                      </span>
                      <button
                        onClick={() => handleDeleteVenue(venue.id)}
                        className="text-gray-500 hover:text-red-400 p-1 transition-colors"
                        title="Delete Venue"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <h3 className="text-base font-bold text-white">{venue.name}</h3>
                    <p className="text-xs text-[#8D98A7] flex items-center gap-1 mt-1">
                      <MapPin className="w-3 h-3 text-[#5C98A7]" />
                      {venue.address}, {venue.city}
                    </p>

                    <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-[#0a2e73] text-xs text-[#C2D8DF]">
                      <div className="bg-[#02050A]/60 p-2 rounded-xl">
                        <span className="text-[#8D98A7] block text-[10px]">Grid Layout</span>
                        <strong className="text-white">{venue.totalRows} Rows × {venue.seatsPerRow} Cols</strong>
                      </div>
                      <div className="bg-[#02050A]/60 p-2 rounded-xl">
                        <span className="text-[#8D98A7] block text-[10px]">Capacity</span>
                        <strong className="text-[#2ECC71]">{venue._count?.seats || venue.totalRows * venue.seatsPerRow} Seats</strong>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-2 flex items-center gap-2 text-[11px] text-[#5C98A7]">
                    <Grid className="w-3.5 h-3.5" />
                    <span>{venue._count?.events || 0} active event screening(s)</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminVenuesPage;
