import React, { useMemo } from 'react';
import { Sparkles, Lock } from 'lucide-react';

export const SeatMap = ({ seats = [], selectedSeatIds = [], onToggleSeat }) => {
  // Group seats by row (e.g. Row 'A', Row 'B')
  const rowsMap = useMemo(() => {
    const map = {};
    for (const seat of seats) {
      if (!map[seat.row]) map[seat.row] = [];
      map[seat.row].push(seat);
    }
    // Sort seats in each row by seat number
    for (const row in map) {
      map[row].sort((a, b) => a.number - b.number);
    }
    return map;
  }, [seats]);

  const rowKeys = Object.keys(rowsMap).sort();

  return (
    <div className="w-full flex flex-col items-center select-none py-6">
      {/* Cinema Screen Curve */}
      <div className="w-full max-w-2xl mb-12 flex flex-col items-center">
        <div className="w-full h-3 rounded-[50%] bg-gradient-to-r from-transparent via-[#044BDD] to-transparent cinema-screen-glow"></div>
        <div className="w-4/5 h-8 border-t-2 border-[#044BDD]/40 rounded-t-[100px] flex items-center justify-center mt-1">
          <span className="text-[11px] font-bold uppercase tracking-[0.3em] text-[#5C98A7]">
            Screen / Stage
          </span>
        </div>
      </div>

      {/* Seating Grid */}
      <div className="w-full overflow-x-auto pb-4 flex justify-center">
        <div className="min-w-[480px] flex flex-col gap-3 px-4">
          {rowKeys.map((rowKey) => {
            const rowSeats = rowsMap[rowKey];
            const isPremiumRow = rowSeats.some((s) => s.categoryName?.toLowerCase().includes('prem'));

            return (
              <div key={rowKey} className="flex items-center justify-center gap-2 sm:gap-3">
                {/* Row Label Left */}
                <div className="w-6 text-center text-xs font-bold text-[#8D98A7]">
                  {rowKey}
                </div>

                {/* Seats in Row */}
                <div className="flex items-center gap-1.5 sm:gap-2">
                  {rowSeats.map((seat, index) => {
                    const isSelected = selectedSeatIds.includes(seat.id);
                    const isHeldByMe = seat.isHeldByMe;
                    const isHeldByOther = seat.status === 'HELD' && !isHeldByMe;
                    const isBooked = seat.status === 'BOOKED';
                    const isOffered = seat.status === 'OFFERED';
                    const isAvailable = seat.status === 'AVAILABLE' || isHeldByMe;

                    // Middle aisle gap
                    const addAisle = rowSeats.length > 6 && index === Math.floor(rowSeats.length / 2);

                    let seatStyle = 'bg-[#031435] border border-[#5C98A7]/60 text-[#C2D8DF] hover:border-[#044BDD] hover:scale-110 cursor-pointer';

                    if (isBooked) {
                      seatStyle = 'bg-[#121926] border border-[#1f293d] text-gray-600 opacity-40 cursor-not-allowed';
                    } else if (isOffered) {
                      seatStyle = 'bg-amber-950/40 border border-amber-500/60 text-amber-300 opacity-70 cursor-not-allowed';
                    } else if (isHeldByOther) {
                      seatStyle = 'bg-[#0a2048] border border-[#F5B942]/70 text-[#F5B942] opacity-80 cursor-not-allowed';
                    } else if (isSelected) {
                      seatStyle = 'bg-[#044BDD] border-2 border-white text-white shadow-glow-blue scale-110 font-bold';
                    } else if (isPremiumRow) {
                      seatStyle = 'bg-[#052053] border border-[#044BDD] text-[#C2D8DF] hover:border-white hover:scale-110 cursor-pointer';
                    }

                    return (
                      <React.Fragment key={seat.id}>
                        {addAisle && <div className="w-4 sm:w-6" />}
                        <button
                          type="button"
                          disabled={isBooked || isHeldByOther || isOffered}
                          onClick={() => onToggleSeat(seat)}
                          title={`Seat ${seat.seatLabel} (${seat.categoryName}) - $${seat.price} - [${seat.status}]`}
                          className={`w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center text-[11px] font-semibold transition-all duration-150 relative group ${seatStyle}`}
                        >
                          {isHeldByOther ? (
                            <Lock className="w-3 h-3 text-[#F5B942]" />
                          ) : isBooked ? (
                            '✕'
                          ) : (
                            seat.number
                          )}

                          {/* Hover Tooltip */}
                          <div className="absolute bottom-full mb-2 hidden group-hover:flex flex-col items-center pointer-events-none z-30">
                            <div className="bg-[#052053] text-white text-[10px] px-2 py-1 rounded shadow-xl border border-[#044BDD] whitespace-nowrap">
                              <p className="font-bold">{seat.seatLabel} · {seat.categoryName}</p>
                              <p className="text-[#5C98A7]">${seat.price.toFixed(2)} · {seat.status}</p>
                            </div>
                            <div className="w-1.5 h-1.5 bg-[#052053] border-r border-b border-[#044BDD] transform rotate-45 -mt-1"></div>
                          </div>
                        </button>
                      </React.Fragment>
                    );
                  })}
                </div>

                {/* Row Label Right */}
                <div className="w-6 text-center text-xs font-bold text-[#8D98A7]">
                  {rowKey}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default SeatMap;
