import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Film, User, Mail, Lock, Shield, ArrowRight, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const RegisterPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('CUSTOMER');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await register(name, email, password, role);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen py-16 px-4 flex items-center justify-center">
      <div className="max-w-md w-full bg-[#052053]/50 border border-[#052053] rounded-3xl p-8 shadow-2xl backdrop-blur-md">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#044BDD] to-[#5C98A7] flex items-center justify-center mx-auto mb-3 shadow-glow-blue">
            <Film className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-extrabold text-white">Create Account</h1>
          <p className="text-xs text-[#8D98A7] mt-1">Join the premier cinema and concert booking platform</p>
        </div>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-950/70 border border-red-500/70 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-[#8D98A7] font-semibold mb-1.5">Full Name</label>
            <div className="relative">
              <User className="w-4 h-4 text-[#8D98A7] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                placeholder="John Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-[#8D98A7] focus:outline-none focus:border-[#044BDD]"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#8D98A7] font-semibold mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-[#8D98A7] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-[#8D98A7] focus:outline-none focus:border-[#044BDD]"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#8D98A7] font-semibold mb-1.5">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#8D98A7] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-[#8D98A7] focus:outline-none focus:border-[#044BDD]"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#8D98A7] font-semibold mb-1.5">Account Role</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setRole('CUSTOMER')}
                className={`py-2 px-3 rounded-xl border text-center transition-all ${
                  role === 'CUSTOMER'
                    ? 'bg-[#044BDD] border-white text-white font-bold'
                    : 'bg-[#031435] border-[#0a2e73] text-[#8D98A7]'
                }`}
              >
                Customer
              </button>
              <button
                type="button"
                onClick={() => setRole('ORGANISER')}
                className={`py-2 px-3 rounded-xl border text-center transition-all ${
                  role === 'ORGANISER'
                    ? 'bg-purple-600 border-white text-white font-bold'
                    : 'bg-[#031435] border-[#0a2e73] text-[#8D98A7]'
                }`}
              >
                Event Organiser
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-4 rounded-2xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-extrabold text-sm shadow-cinematic transition-all hover:scale-102 disabled:opacity-50 mt-2 flex items-center justify-center gap-2"
          >
            <span>{loading ? 'Creating Account...' : 'Register Account'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <p className="text-center text-xs text-[#8D98A7] mt-6">
          Already have an account?{' '}
          <Link to="/login" className="text-[#044BDD] hover:underline font-semibold">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
};

export default RegisterPage;
