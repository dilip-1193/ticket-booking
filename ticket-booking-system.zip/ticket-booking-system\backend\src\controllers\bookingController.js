import { bookingService } from '../services/bookingService.js';

export const bookingController = {
  async createBooking(req, res, next) {
    try {
      const { eventId, showSeatIds } = req.body;
      const userId = req.user.id;

      const result = await bookingService.createBooking(eventId, showSeatIds, userId);
      res.status(201).json(result);
    } catch (error) {
      next(error);
    }
  },

  async getMyBookings(req, res, next) {
    try {
      const userId = req.user.id;
      const bookings = await bookingService.getUserBookings(userId);
      res.json({ success: true, bookings });
    } catch (error) {
      next(error);
    }
  },

  async getBookingById(req, res, next) {
    try {
      const { id } = req.params;
      const booking = await bookingService.getBookingById(id, req.user.id, req.user.role);
      res.json({ success: true, booking });
    } catch (error) {
      next(error);
    }
  },

  async cancelBooking(req, res, next) {
    try {
      const { id } = req.params;
      const result = await bookingService.cancelBooking(id, req.user.id, req.user.role);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
};
