import nodemailer from 'nodemailer';
import { ENV } from '../config/env.js';
import { logger } from '../utils/logger.js';

class EmailService {
  constructor() {
    this.transporter = null;
    this.initTransporter();
  }

  async initTransporter() {
    try {
      if (ENV.EMAIL_USER && ENV.EMAIL_PASSWORD) {
        this.transporter = nodemailer.createTransport({
          host: ENV.EMAIL_HOST,
          port: ENV.EMAIL_PORT,
          secure: ENV.EMAIL_PORT === 465,
          auth: {
            user: ENV.EMAIL_USER,
            pass: ENV.EMAIL_PASSWORD,
          },
        });
        logger.info('SMTP Transporter configured with environment credentials.');
      } else {
        logger.info('No email credentials provided. Using virtual email dispatcher for test & demo preview.');
      }
    } catch (error) {
      logger.warn('Failed to initialize nodemailer transporter:', error.message);
    }
  }

  /**
   * Send confirmed booking email with embedded QR code
   */
  async sendBookingConfirmation(user, booking, event, seats) {
    const seatLabels = seats.map((s) => s.seatLabel).join(', ');
    const subject = `Booking Confirmed: ${event.title} [${booking.bookingReference}]`;

    const html = `
      <div style="font-family: Arial, sans-serif; background-color: #02050A; color: #FFFFFF; padding: 24px; border-radius: 12px; max-width: 600px; margin: auto;">
        <div style="border-bottom: 2px solid #044BDD; padding-bottom: 16px; margin-bottom: 20px;">
          <h1 style="color: #044BDD; margin: 0; font-size: 24px;">TICKET BOOKING SYSTEM</h1>
          <p style="color: #8D98A7; margin: 4px 0 0 0;">Your tickets are confirmed!</p>
        </div>

        <div style="background-color: #052053; padding: 20px; border-radius: 8px; border: 1px solid #1a3a70; margin-bottom: 20px;">
          <h2 style="margin-top: 0; color: #FFFFFF; font-size: 20px;">${event.title}</h2>
          <p style="color: #C2D8DF; margin: 6px 0;"><strong>Date:</strong> ${new Date(event.eventDate).toLocaleDateString()} at ${event.showTime}</p>
          <p style="color: #C2D8DF; margin: 6px 0;"><strong>Venue:</strong> ${event.venue?.name || 'Main Hall'}</p>
          <p style="color: #C2D8DF; margin: 6px 0;"><strong>Seats:</strong> <span style="color: #2ECC71; font-weight: bold;">${seatLabels}</span></p>
          <p style="color: #C2D8DF; margin: 6px 0;"><strong>Booking Reference:</strong> <span style="font-family: monospace; font-size: 16px; color: #5C98A7;">${booking.bookingReference}</span></p>
          <p style="color: #C2D8DF; margin: 6px 0;"><strong>Total Amount:</strong> $${booking.totalAmount.toFixed(2)}</p>
        </div>

        <div style="text-align: center; background: #ffffff; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
          <p style="color: #02050A; font-weight: bold; margin-bottom: 10px;">Scan at the entrance:</p>
          <img src="${booking.qrCodeData}" alt="QR Ticket" style="width: 220px; height: 220px;" />
          <p style="color: #555555; font-size: 12px; margin-top: 8px;">Reference: ${booking.bookingReference}</p>
        </div>

        <p style="color: #8D98A7; font-size: 12px; text-align: center;">
          Thank you for choosing Ticket Booking System. Present this digital ticket at the gate.
        </p>
      </div>
    `;

    logger.info(`[EMAIL DISPATCH] Sent booking confirmation to ${user.email} for Ref: ${booking.bookingReference}`);

    if (this.transporter) {
      try {
        await this.transporter.sendMail({
          from: ENV.EMAIL_FROM,
          to: user.email,
          subject,
          html,
        });
      } catch (err) {
        logger.warn('Could not send live SMTP email:', err.message);
      }
    }

    return { sent: true, recipient: user.email, reference: booking.bookingReference };
  }

  /**
   * Send time-limited waitlist offer email
   */
  async sendWaitlistOffer(user, event, seat, offer, claimUrl) {
    const subject = `Seat Available! Time-Limited Offer for ${event.title}`;

    const html = `
      <div style="font-family: Arial, sans-serif; background-color: #02050A; color: #FFFFFF; padding: 24px; border-radius: 12px; max-width: 600px; margin: auto;">
        <div style="border-bottom: 2px solid #2ECC71; padding-bottom: 16px; margin-bottom: 20px;">
          <h1 style="color: #2ECC71; margin: 0; font-size: 24px;">GREAT NEWS! A SEAT OPENED UP</h1>
          <p style="color: #8D98A7; margin: 4px 0 0 0;">You're next on the waitlist</p>
        </div>

        <div style="background-color: #052053; padding: 20px; border-radius: 8px; border: 1px solid #1a3a70; margin-bottom: 20px;">
          <h2 style="margin-top: 0; color: #FFFFFF;">${event.title}</h2>
          <p style="color: #C2D8DF; margin: 6px 0;"><strong>Category:</strong> ${seat.categoryName}</p>
          <p style="color: #C2D8DF; margin: 6px 0;"><strong>Assigned Seat:</strong> <span style="color: #2ECC71; font-weight: bold;">${seat.seatLabel}</span></p>
          <p style="color: #C2D8DF; margin: 6px 0;"><strong>Price:</strong> $${seat.price.toFixed(2)}</p>
          <p style="color: #F5B942; margin: 12px 0 6px 0; font-weight: bold;">
            ⏳ Time remaining to claim: ${ENV.WAITLIST_OFFER_TTL_MINUTES} minutes (Expires at: ${new Date(offer.expiresAt).toLocaleTimeString()})
          </p>
        </div>

        <div style="text-align: center; margin: 30px 0;">
          <a href="${claimUrl}" style="background-color: #044BDD; color: #FFFFFF; text-decoration: none; padding: 14px 28px; border-radius: 8px; font-weight: bold; font-size: 16px; display: inline-block;">
            CLAIM YOUR SEAT NOW
          </a>
        </div>

        <p style="color: #8D98A7; font-size: 12px; text-align: center;">
          If you do not complete your claim before the timer expires, this seat will automatically be offered to the next waitlisted customer.
        </p>
      </div>
    `;

    logger.info(`[WAITLIST EMAIL] Sent time-limited offer to ${user.email} for Seat ${seat.seatLabel}. Claim URL: ${claimUrl}`);

    if (this.transporter) {
      try {
        await this.transporter.sendMail({
          from: ENV.EMAIL_FROM,
          to: user.email,
          subject,
          html,
        });
      } catch (err) {
        logger.warn('Could not send live SMTP email for waitlist:', err.message);
      }
    }

    return { sent: true, recipient: user.email, offerId: offer.id };
  }
}

export const emailService = new EmailService();
