import prisma from '../config/db.js';

export const venueController = {
  async getAllVenues(req, res, next) {
    try {
      const venues = await prisma.venue.findMany({
        include: {
          seatCategories: true,
          _count: { select: { seats: true, events: true } },
        },
        orderBy: { name: 'asc' },
      });
      res.json({ success: true, venues });
    } catch (error) {
      next(error);
    }
  },

  async getVenueById(req, res, next) {
    try {
      const { id } = req.params;
      const venue = await prisma.venue.findUnique({
        where: { id },
        include: {
          seatCategories: true,
          seats: {
            include: { category: true },
            orderBy: [{ row: 'asc' }, { number: 'asc' }],
          },
        },
      });

      if (!venue) {
        return res.status(404).json({ success: false, message: 'Venue not found' });
      }

      res.json({ success: true, venue });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Admin creates a new venue with customizable row/column seating and categories
   */
  async createVenue(req, res, next) {
    try {
      const { name, city, address, totalRows = 6, seatsPerRow = 10, premiumRowsCount = 2 } = req.body;

      if (!name || !city || !address) {
        return res.status(400).json({ success: false, message: 'Venue name, city, and address are required' });
      }

      const rowsCount = Math.min(Math.max(parseInt(totalRows, 10) || 6, 1), 26);
      const colsCount = Math.min(Math.max(parseInt(seatsPerRow, 10) || 10, 1), 30);
      const premCount = Math.min(parseInt(premiumRowsCount, 10) || 2, rowsCount);

      const venue = await prisma.$transaction(async (tx) => {
        // Create venue
        const createdVenue = await tx.venue.create({
          data: {
            name: name.trim(),
            city: city.trim(),
            address: address.trim(),
            totalRows: rowsCount,
            seatsPerRow: colsCount,
          },
        });

        // Create categories
        const premiumCat = await tx.seatCategory.create({
          data: {
            venueId: createdVenue.id,
            name: 'Premium',
            color: '#044BDD',
            basePriceMultiplier: 1.5,
          },
        });

        const standardCat = await tx.seatCategory.create({
          data: {
            venueId: createdVenue.id,
            name: 'Standard',
            color: '#5C98A7',
            basePriceMultiplier: 1.0,
          },
        });

        // Create seats
        const seatsData = [];
        for (let r = 0; r < rowsCount; r++) {
          const rowLetter = String.fromCharCode(65 + r); // A, B, C...
          const categoryId = r < premCount ? premiumCat.id : standardCat.id;

          for (let c = 1; c <= colsCount; c++) {
            seatsData.push({
              venueId: createdVenue.id,
              row: rowLetter,
              number: c,
              seatLabel: `${rowLetter}${c}`,
              categoryId,
            });
          }
        }

        for (const seat of seatsData) {
          await tx.seat.create({ data: seat });
        }

        return createdVenue;
      });

      const fullVenue = await prisma.venue.findUnique({
        where: { id: venue.id },
        include: { seatCategories: true, seats: true },
      });

      res.status(201).json({
        success: true,
        message: 'Venue and seat layout created successfully',
        venue: fullVenue,
      });
    } catch (error) {
      next(error);
    }
  },

  async deleteVenue(req, res, next) {
    try {
      const { id } = req.params;
      await prisma.venue.delete({ where: { id } });
      res.json({ success: true, message: 'Venue deleted successfully' });
    } catch (error) {
      next(error);
    }
  },
};
