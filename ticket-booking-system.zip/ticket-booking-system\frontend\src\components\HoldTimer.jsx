import React, { useEffect, useState } from 'react';
import { Timer, AlertTriangle } from 'lucide-react';

export const HoldTimer = ({ expiresAt, onExpired }) => {
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (!expiresAt) return;

    const calculateTime = () => {
      const diff = Math.max(0, Math.floor((new Date(expiresAt).getTime() - Date.now()) / 1000));
      setTimeLeft(diff);
      if (diff === 0 && onExpired) {
        onExpired();
      }
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);

    return () => clearInterval(interval);
  }, [expiresAt, onExpired]);

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  // Visual urgency styling
  const isCritical = timeLeft <= 30;
  const isWarning = timeLeft <= 120 && !isCritical;

  let badgeColor = 'bg-[#044BDD]/20 border-[#044BDD] text-[#C2D8DF]';
  let timerTextColor = 'text-[#2ECC71]';

  if (isCritical) {
    badgeColor = 'bg-[#FF5C5C]/20 border-[#FF5C5C] text-white animate-pulse';
    timerTextColor = 'text-[#FF5C5C]';
  } else if (isWarning) {
    badgeColor = 'bg-[#F5B942]/20 border-[#F5B942] text-white';
    timerTextColor = 'text-[#F5B942]';
  }

  if (timeLeft === 0) {
    return (
      <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border bg-red-950/40 border-red-500/50 text-red-300 text-xs font-semibold">
        <AlertTriangle className="w-4 h-4 text-red-400" />
        <span>Hold Expired - Seats Released</span>
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-2.5 px-4 py-2 rounded-xl border backdrop-blur-md transition-all ${badgeColor}`}>
      <Timer className={`w-4 h-4 ${timerTextColor}`} />
      <div className="text-xs">
        <span className="text-[#8D98A7] mr-1.5 font-medium">Seats Held:</span>
        <span className={`font-mono font-bold text-sm tracking-wider ${timerTextColor}`}>
          {formattedTime}
        </span>
      </div>
    </div>
  );
};

export default HoldTimer;
