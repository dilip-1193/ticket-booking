import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, MapPin, Film, Music, ArrowRight } from 'lucide-react';

export const EventCard = ({ event }) => {
  const isMovie = event.type === 'MOVIE';
  const startPrice = event.standardPrice || event.premiumPrice || 0;
  const isSoldOut = event.isSoldOut || event.availableSeatsCount === 0;

  return (
    <div className="group relative bg-[#052053]/60 border border-[#052053] hover:border-[#044BDD] rounded-3xl overflow-hidden transition-all duration-300 hover:-translate-y-1.5 hover:shadow-cinematic flex flex-col justify-between">
      {/* Poster Image */}
      <div className="relative aspect-[16/9] sm:aspect-[4/3] overflow-hidden bg-[#031435]">
        <img
          src={event.posterUrl || 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&auto=format&fit=crop&q=80'}
          alt={event.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#052053] via-transparent to-black/40"></div>

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
          <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-[#02050A]/80 backdrop-blur-md border border-[#044BDD]/40 text-[#C2D8DF] flex items-center gap-1.5">
            {isMovie ? <Film className="w-3 h-3 text-[#044BDD]" /> : <Music className="w-3 h-3 text-[#2ECC71]" />}
            {event.type}
          </span>

          {isSoldOut ? (
            <span className="px-3 py-1 rounded-full text-[11px] font-extrabold bg-red-950/80 border border-red-500/80 text-red-300">
              SOLD OUT
            </span>
          ) : (
            <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-[#044BDD] text-white shadow-glow-blue">
              ${startPrice.toFixed(0)}+
            </span>
          )}
        </div>

        {/* Genre Tag */}
        <div className="absolute bottom-3 left-3">
          <span className="text-[11px] font-medium text-[#5C98A7] bg-[#02050A]/90 px-2.5 py-1 rounded-lg border border-[#0a2e73]">
            {event.genre}
          </span>
        </div>
      </div>

      {/* Details */}
      <div className="p-5 flex flex-col flex-grow justify-between">
        <div>
          <h3 className="text-lg font-bold text-white group-hover:text-[#5C98A7] transition-colors line-clamp-1">
            {event.title}
          </h3>

          <p className="text-xs text-[#8D98A7] line-clamp-2 mt-1.5 mb-4 leading-relaxed">
            {event.description}
          </p>
        </div>

        <div>
          <div className="space-y-1.5 text-xs text-[#C2D8DF] pt-3 border-t border-[#0a2e73] mb-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-[#5C98A7]" />
              <span>{new Date(event.eventDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
              <span className="text-gray-500">·</span>
              <Clock className="w-3.5 h-3.5 text-[#5C98A7]" />
              <span>{event.showTime}</span>
            </div>

            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-[#5C98A7]" />
              <span className="truncate">{event.venue?.name || 'Grand Cinema Arena'}</span>
            </div>
          </div>

          {/* Action CTA */}
          <Link
            to={`/events/${event.id}`}
            className="w-full py-2.5 px-4 rounded-xl bg-[#044BDD] hover:bg-[#0337A0] text-white text-xs font-bold transition-all shadow-cinematic flex items-center justify-center gap-2 group-hover:shadow-glow-blue"
          >
            <span>{isSoldOut ? 'Join Waitlist' : 'Select Seats'}</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default EventCard;
