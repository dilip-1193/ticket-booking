import crypto from 'crypto';
import prisma from '../config/db.js';
import { ENV } from '../config/env.js';
import { emailService } from './emailService.js';
import { qrService } from './qrService.js';
import { broadcastSeatUpdate, broadcastWaitlistOffer } from '../sockets/socketHandler.js';
import { logger } from '../utils/logger.js';

export const waitlistService = {
  /**
   * Join waitlist for a specific event and seat category
   */
  async joinWaitlist(eventId, userId, seatCategoryName) {
    const event = await prisma.event.findUnique({ where: { id: eventId } });
    if (!event) {
      const err = new Error('Event not found');
      err.statusCode = 404;
      throw err;
    }

    // Check if user is already actively waiting or offered
    const existing = await prisma.waitlistEntry.findFirst({
      where: {
        eventId,
        userId,
        seatCategoryName,
        status: { in: ['WAITING', 'OFFERED'] },
      },
    });

    if (existing) {
      const err = new Error(`You are already on the waitlist for ${seatCategoryName} seats for this event.`);
      err.statusCode = 400;
      throw err;
    }

    // Calculate queue position (count active entries ahead + 1)
    const activeCountAhead = await prisma.waitlistEntry.count({
      where: {
        eventId,
        seatCategoryName,
        status: 'WAITING',
      },
    });

    const position = activeCountAhead + 1;

    const entry = await prisma.waitlistEntry.create({
      data: {
        eventId,
        userId,
        seatCategoryName,
        position,
        status: 'WAITING',
      },
      include: {
        event: { select: { title: true, eventDate: true, showTime: true } },
      },
    });

    logger.info(`User ${userId} joined waitlist for Event ${eventId}, Category: ${seatCategoryName} (Position #${position})`);

    return {
      success: true,
      message: `Successfully joined waitlist for ${seatCategoryName} category.`,
      entry: {
        id: entry.id,
        eventId: entry.eventId,
        eventTitle: entry.event.title,
        seatCategoryName: entry.seatCategoryName,
        position,
        status: entry.status,
        createdAt: entry.createdAt,
      },
    };
  },

  /**
   * Get user's waitlist entries
   */
  async getUserWaitlists(userId) {
    const entries = await prisma.waitlistEntry.findMany({
      where: { userId },
      include: {
        event: {
          select: {
            id: true,
            title: true,
            eventDate: true,
            showTime: true,
            posterUrl: true,
            venue: { select: { name: true } },
          },
        },
        offers: {
          where: { status: 'PENDING' },
          include: {
            showSeat: { select: { seatLabel: true, price: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return entries;
  },

  /**
   * Triggered when a booking is cancelled or seat opens:
   * Finds the top FIFO candidate for the category and creates a time-limited offer.
   */
  async processSeatFreed(eventId, categoryName, showSeatId) {
    logger.info(`Processing waitlist for freed seat ${showSeatId} in Category: ${categoryName} (Event: ${eventId})`);

    const result = await prisma.$transaction(async (tx) => {
      // Find oldest active waitlisted user (FIFO)
      const nextCandidate = await tx.waitlistEntry.findFirst({
        where: {
          eventId,
          seatCategoryName: categoryName,
          status: 'WAITING',
        },
        orderBy: { createdAt: 'asc' },
        include: {
          user: true,
          event: { include: { venue: true } },
        },
      });

      if (!nextCandidate) {
        logger.info(`No active waitlist candidate found for Event ${eventId}, Category ${categoryName}. Releasing seat.`);
        // Mark seat available
        await tx.showSeat.update({
          where: { id: showSeatId },
          data: {
            status: 'AVAILABLE',
            heldByUserId: null,
            holdExpiresAt: null,
            version: { increment: 1 },
          },
        });
        return { assigned: false };
      }

      const ttlMinutes = ENV.WAITLIST_OFFER_TTL_MINUTES || 5;
      const expiresAt = new Date(Date.now() + ttlMinutes * 60 * 1000);
      const token = crypto.randomBytes(24).toString('hex');

      // Update ShowSeat to OFFERED
      const seat = await tx.showSeat.update({
        where: { id: showSeatId },
        data: {
          status: 'OFFERED',
          heldByUserId: nextCandidate.userId,
          holdExpiresAt: expiresAt,
          version: { increment: 1 },
        },
      });

      // Update waitlist entry to OFFERED
      await tx.waitlistEntry.update({
        where: { id: nextCandidate.id },
        data: { status: 'OFFERED' },
      });

      // Create WaitlistOffer record
      const offer = await tx.waitlistOffer.create({
        data: {
          waitlistEntryId: nextCandidate.id,
          eventId,
          userId: nextCandidate.userId,
          showSeatId,
          token,
          expiresAt,
          status: 'PENDING',
        },
      });

      return {
        assigned: true,
        candidate: nextCandidate,
        seat,
        offer,
        token,
        expiresAt,
      };
    });

    if (result.assigned) {
      const { candidate, seat, offer, token, expiresAt } = result;
      const claimUrl = `${ENV.FRONTEND_URL}/waitlist/claim/${token}`;

      // Send email to the chosen customer
      emailService.sendWaitlistOffer(candidate.user, candidate.event, seat, offer, claimUrl).catch((err) => {
        logger.error('Failed to send waitlist offer email:', err);
      });

      // Emit real-time notification to user
      broadcastWaitlistOffer(candidate.userId, {
        offerId: offer.id,
        token,
        eventId,
        eventTitle: candidate.event.title,
        seatLabel: seat.seatLabel,
        categoryName: seat.categoryName,
        price: seat.price,
        expiresAt,
        claimUrl,
      });

      // Broadcast seat status update
      broadcastSeatUpdate(eventId, {
        type: 'SEAT_OFFERED',
        eventId,
        seatId: seat.id,
        categoryName: seat.categoryName,
      });

      logger.info(`Offered seat ${seat.seatLabel} to Waitlist Customer ${candidate.user.email} (Offer expires: ${expiresAt.toISOString()})`);
    } else {
      // Seat was made AVAILABLE
      broadcastSeatUpdate(eventId, {
        type: 'SEAT_RELEASED',
        eventId,
        seatIds: [showSeatId],
      });
    }

    return result;
  },

  /**
   * Get offer details by token
   */
  async getOfferByToken(token) {
    const offer = await prisma.waitlistOffer.findUnique({
      where: { token },
      include: {
        event: { include: { venue: true } },
        showSeat: true,
        user: { select: { id: true, name: true, email: true } },
      },
    });

    if (!offer) {
      const err = new Error('Offer not found or invalid link');
      err.statusCode = 404;
      throw err;
    }

    const isExpired = new Date(offer.expiresAt) < new Date();
    if (offer.status !== 'PENDING' || isExpired) {
      return {
        ...offer,
        isExpired: true,
        status: 'EXPIRED',
      };
    }

    return {
      ...offer,
      isExpired: false,
    };
  },

  /**
   * Customer claims their waitlist offer and completes booking
   */
  async claimWaitlistOffer(token, userId) {
    const result = await prisma.$transaction(async (tx) => {
      const offer = await tx.waitlistOffer.findUnique({
        where: { token },
        include: {
          event: { include: { venue: true } },
          showSeat: true,
          user: true,
        },
      });

      if (!offer) {
        const err = new Error('Offer not found');
        err.statusCode = 404;
        throw err;
      }

      if (offer.userId !== userId) {
        const err = new Error('Unauthorized: This offer was assigned to a different user account');
        err.statusCode = 403;
        throw err;
      }

      if (offer.status !== 'PENDING' || new Date(offer.expiresAt) < new Date()) {
        const err = new Error('This booking offer has expired.');
        err.statusCode = 410;
        throw err;
      }

      // Generate booking reference
      const refSuffix = crypto.randomBytes(3).toString('hex').toUpperCase();
      const bookingReference = `TBS-${new Date().getFullYear()}-${refSuffix}`;

      // Update seat to BOOKED
      await tx.showSeat.update({
        where: { id: offer.showSeatId },
        data: {
          status: 'BOOKED',
          heldByUserId: null,
          holdExpiresAt: null,
          version: { increment: 1 },
        },
      });

      // Update offer and waitlist entry to CLAIMED
      await tx.waitlistOffer.update({
        where: { id: offer.id },
        data: { status: 'CLAIMED' },
      });

      await tx.waitlistEntry.update({
        where: { id: offer.waitlistEntryId },
        data: { status: 'CLAIMED' },
      });

      // Create Booking record
      const booking = await tx.booking.create({
        data: {
          bookingReference,
          userId,
          eventId: offer.eventId,
          totalAmount: offer.showSeat.price,
          status: 'CONFIRMED',
          bookingSeats: {
            create: [
              {
                showSeatId: offer.showSeatId,
                seatLabel: offer.showSeat.seatLabel,
                categoryName: offer.showSeat.categoryName,
                price: offer.showSeat.price,
              },
            ],
          },
        },
        include: {
          bookingSeats: true,
          event: { include: { venue: true } },
          user: true,
        },
      });

      // Generate Ticket
      const ticketNumber = `TKT-${bookingReference}-1`;
      const ticket = await tx.ticket.create({
        data: {
          bookingId: booking.id,
          ticketNumber,
        },
      });

      return { booking, ticket, offer };
    });

    // Generate QR Code and update booking
    const qrDataUrl = await qrService.generateTicketQR(result.booking.bookingReference, {
      eventTitle: result.booking.event.title,
      seats: [result.offer.showSeat.seatLabel],
      customerName: result.booking.user.name,
    });

    const finalBooking = await prisma.booking.update({
      where: { id: result.booking.id },
      data: { qrCodeData: qrDataUrl },
      include: {
        bookingSeats: true,
        event: { include: { venue: true } },
        tickets: true,
        user: true,
      },
    });

    // Broadcast seat status update
    broadcastSeatUpdate(result.offer.eventId, {
      type: 'SEAT_BOOKED',
      eventId: result.offer.eventId,
      seatIds: [result.offer.showSeatId],
    });

    // Send confirmation email
    emailService.sendBookingConfirmation(finalBooking.user, finalBooking, finalBooking.event, finalBooking.bookingSeats).catch((err) => {
      logger.error('Failed to send confirmation email on claimed waitlist:', err);
    });

    logger.info(`Waitlist offer ${token} successfully claimed by User ${userId}. Booking Ref: ${finalBooking.bookingReference}`);

    return {
      success: true,
      message: 'Waitlist offer successfully claimed! Booking confirmed.',
      booking: finalBooking,
    };
  },

  /**
   * Background worker to check expired waitlist offers and cycle to next customer
   */
  async processExpiredOffers() {
    const now = new Date();

    try {
      const expiredOffers = await prisma.waitlistOffer.findMany({
        where: {
          status: 'PENDING',
          expiresAt: { lte: now },
        },
        include: {
          showSeat: true,
        },
      });

      if (expiredOffers.length === 0) return 0;

      for (const offer of expiredOffers) {
        logger.info(`Waitlist offer ${offer.id} expired. Auto-progressing to next customer.`);

        await prisma.$transaction(async (tx) => {
          await tx.waitlistOffer.update({
            where: { id: offer.id },
            data: { status: 'EXPIRED' },
          });

          await tx.waitlistEntry.update({
            where: { id: offer.waitlistEntryId },
            data: { status: 'EXPIRED' },
          });
        });

        // Trigger next customer offer
        await this.processSeatFreed(offer.eventId, offer.showSeat.categoryName, offer.showSeatId);
      }

      return expiredOffers.length;
    } catch (error) {
      logger.error('Error in processExpiredOffers worker:', error);
      return 0;
    }
  },
};
