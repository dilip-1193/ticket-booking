import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';

import Navbar from './components/Navbar';
import WaitlistOfferBanner from './components/WaitlistOfferBanner';

import HomePage from './pages/HomePage';
import EventDetailsPage from './pages/EventDetailsPage';
import SeatSelectionPage from './pages/SeatSelectionPage';
import CheckoutPage from './pages/CheckoutPage';
import BookingConfirmationPage from './pages/BookingConfirmationPage';
import MyBookingsPage from './pages/MyBookingsPage';
import WaitlistsPage from './pages/WaitlistsPage';
import ClaimOfferPage from './pages/ClaimOfferPage';
import OrganiserDashboardPage from './pages/OrganiserDashboardPage';
import AdminVenuesPage from './pages/AdminVenuesPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';

// Protected Route Wrapper
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#02050A]">
        <div className="w-10 h-10 border-4 border-[#044BDD] border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/" replace />;
  }

  return children;
};

export const App = () => {
  return (
    <AuthProvider>
      <SocketProvider>
        <Router>
          <div className="min-h-screen flex flex-col bg-[#02050A] text-white">
            <Navbar />
            <WaitlistOfferBanner />

            <main className="flex-grow">
              <Routes>
                {/* Public Browsing Routes */}
                <Route path="/" element={<HomePage />} />
                <Route path="/events/:id" element={<EventDetailsPage />} />
                <Route path="/events/:id/seats" element={<SeatSelectionPage />} />
                <Route path="/waitlist/claim/:token" element={<ClaimOfferPage />} />

                {/* Auth Routes */}
                <Route path="/login" element={<LoginPage />} />
                <Route path="/register" element={<RegisterPage />} />

                {/* Customer Protected Routes */}
                <Route
                  path="/checkout"
                  element={
                    <ProtectedRoute>
                      <CheckoutPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/bookings/confirmation/:id"
                  element={
                    <ProtectedRoute>
                      <BookingConfirmationPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/my-bookings"
                  element={
                    <ProtectedRoute>
                      <MyBookingsPage />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/waitlists"
                  element={
                    <ProtectedRoute>
                      <WaitlistsPage />
                    </ProtectedRoute>
                  }
                />

                {/* Organiser Portal */}
                <Route
                  path="/organiser"
                  element={
                    <ProtectedRoute allowedRoles={['ORGANISER', 'ADMIN']}>
                      <OrganiserDashboardPage />
                    </ProtectedRoute>
                  }
                />

                {/* Admin Portal */}
                <Route
                  path="/admin/venues"
                  element={
                    <ProtectedRoute allowedRoles={['ADMIN']}>
                      <AdminVenuesPage />
                    </ProtectedRoute>
                  }
                />

                {/* Fallback */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>

            {/* Footer */}
            <footer className="border-t border-[#052053] bg-[#02050A] py-8 text-center text-xs text-[#8D98A7]">
              <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <span className="font-bold text-white tracking-wide">TICKET<span className="text-[#044BDD]">BOOKING</span> SYSTEM</span>
                  <span className="text-gray-500 block text-[11px] mt-0.5">High-Concurrency Cinema & Concert Platform</span>
                </div>
                <div className="flex items-center gap-6">
                  <span>Built with Node.js · Express · Prisma · React · Socket.IO</span>
                </div>
              </div>
            </footer>
          </div>
        </Router>
      </SocketProvider>
    </AuthProvider>
  );
};

export default App;
