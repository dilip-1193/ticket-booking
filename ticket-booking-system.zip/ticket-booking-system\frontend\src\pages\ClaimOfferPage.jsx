import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Sparkles, Timer, ArrowRight, ShieldCheck, AlertTriangle } from 'lucide-react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';

export const ClaimOfferPage = () => {
  const { token } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();

  const [offer, setOffer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [error, setError] = useState('');
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    fetchOffer();
  }, [token]);

  const fetchOffer = async () => {
    try {
      const res = await api.get(`/waitlist/offers/${token}`);
      if (res.data.success) {
        setOffer(res.data.offer);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Offer link is invalid or has expired.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!offer?.expiresAt) return;

    const tick = () => {
      const remaining = Math.max(0, Math.floor((new Date(offer.expiresAt).getTime() - Date.now()) / 1000));
      setTimeLeft(remaining);
      if (remaining === 0) {
        setError('This waitlist offer has expired and was offered to the next customer.');
      }
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [offer]);

  const handleClaim = async () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { returnUrl: `/waitlist/claim/${token}` } });
      return;
    }

    setClaiming(true);
    setError('');

    try {
      const res = await api.post(`/waitlist/offers/${token}/claim`);
      if (res.data.success) {
        navigate(`/bookings/confirmation/${res.data.booking.id}`, {
          state: { booking: res.data.booking },
        });
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to claim seat. Offer may have expired.');
    } finally {
      setClaiming(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-md mx-auto py-24 text-center">
        <div className="w-12 h-12 border-4 border-[#044BDD] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-sm text-[#8D98A7]">Loading Priority Seat Offer...</p>
      </div>
    );
  }

  if (error && !offer) {
    return (
      <div className="max-w-md mx-auto py-24 px-4 text-center">
        <AlertTriangle className="w-12 h-12 text-red-400 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-white mb-2">Offer Expired or Invalid</h2>
        <p className="text-xs text-[#8D98A7] mb-6">{error}</p>
        <Link to="/" className="px-6 py-3 bg-[#044BDD] text-white text-xs font-bold rounded-2xl shadow-cinematic">
          Browse Events
        </Link>
      </div>
    );
  }

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const timeStr = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const event = offer?.event || {};
  const seat = offer?.showSeat || {};

  return (
    <div className="min-h-screen py-16 px-4">
      <div className="max-w-lg mx-auto bg-gradient-to-b from-[#052053] to-[#031435] border-2 border-[#2ECC71] rounded-3xl p-8 shadow-2xl relative text-center">
        <div className="w-14 h-14 rounded-2xl bg-[#2ECC71]/20 border border-[#2ECC71] flex items-center justify-center text-[#2ECC71] mx-auto mb-4 shadow-glow-green">
          <Sparkles className="w-7 h-7" />
        </div>

        <span className="text-xs font-extrabold uppercase tracking-widest text-[#2ECC71] bg-emerald-950/80 px-3 py-1 rounded-full border border-[#2ECC71]/40">
          Priority Waitlist Offer
        </span>

        <h1 className="text-2xl font-extrabold text-white mt-3">{event.title}</h1>
        <p className="text-xs text-[#8D98A7] mt-1">{event.venue?.name} · {event.showTime}</p>

        {error && (
          <div className="p-3 my-4 rounded-xl bg-red-950/70 border border-red-500/70 text-red-200 text-xs">
            {error}
          </div>
        )}

        {/* Offer Details Box */}
        <div className="my-6 bg-[#02050A]/70 border border-[#0a2e73] rounded-2xl p-5 text-left space-y-3 text-xs">
          <div className="flex justify-between items-center">
            <span className="text-[#8D98A7]">Assigned Seat</span>
            <span className="text-base font-extrabold text-[#2ECC71]">{seat.seatLabel} ({seat.categoryName})</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-[#8D98A7]">Total Price</span>
            <span className="text-base font-extrabold text-white">${seat.price?.toFixed(2)}</span>
          </div>

          <div className="pt-2 border-t border-[#0a2e73] flex justify-between items-center">
            <span className="text-[#F5B942] font-semibold flex items-center gap-1">
              <Timer className="w-3.5 h-3.5" /> Time Remaining:
            </span>
            <span className="font-mono text-base font-bold text-[#F5B942]">{timeStr}</span>
          </div>
        </div>

        <button
          onClick={handleClaim}
          disabled={claiming || timeLeft === 0}
          className="w-full py-4 px-6 rounded-2xl bg-[#2ECC71] hover:bg-emerald-400 text-[#02050A] font-extrabold text-sm shadow-glow-green transition-all hover:scale-102 disabled:opacity-40 flex items-center justify-center gap-2"
        >
          <span>{claiming ? 'Confirming Ticket...' : 'Claim & Issue My Ticket'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <p className="text-[11px] text-[#8D98A7] mt-4">
          If not claimed before timer expires, this seat will automatically advance to the next waitlisted customer.
        </p>
      </div>
    </div>
  );
};

export default ClaimOfferPage;
