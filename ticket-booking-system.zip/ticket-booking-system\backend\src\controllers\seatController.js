import { seatService } from '../services/seatService.js';

export const seatController = {
  async getSeats(req, res, next) {
    try {
      const { eventId } = req.params;
      const currentUserId = req.user?.id || null;

      const seats = await seatService.getSeatsForEvent(eventId, currentUserId);
      res.json({ success: true, seats });
    } catch (error) {
      next(error);
    }
  },

  async holdSeats(req, res, next) {
    try {
      const { eventId } = req.params;
      const { showSeatIds } = req.body;
      const userId = req.user.id;

      const result = await seatService.holdSeats(eventId, showSeatIds, userId);
      res.status(200).json(result);
    } catch (error) {
      next(error);
    }
  },

  async releaseHold(req, res, next) {
    try {
      const { eventId } = req.params;
      const { showSeatIds } = req.body;
      const userId = req.user.id;

      const result = await seatService.releaseSeatHolds(eventId, showSeatIds, userId);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
};
