import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSocket } from '../context/SocketContext';
import { Sparkles, Timer, ArrowRight, X } from 'lucide-react';

export const WaitlistOfferBanner = () => {
  const { activeOffer, dismissOffer } = useSocket();
  const navigate = useNavigate();
  const [secondsRemaining, setSecondsRemaining] = useState(0);

  useEffect(() => {
    if (!activeOffer?.expiresAt) return;

    const tick = () => {
      const remaining = Math.max(0, Math.floor((new Date(activeOffer.expiresAt).getTime() - Date.now()) / 1000));
      setSecondsRemaining(remaining);
      if (remaining === 0) {
        dismissOffer();
      }
    };

    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [activeOffer, dismissOffer]);

  if (!activeOffer || secondsRemaining === 0) return null;

  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;
  const timerStr = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const handleClaim = () => {
    navigate(`/waitlist/claim/${activeOffer.token}`);
    dismissOffer();
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md w-full animate-in slide-in-from-bottom-5 duration-300">
      <div className="bg-gradient-to-r from-[#052053] to-[#044BDD] border-2 border-[#2ECC71] rounded-3xl p-5 shadow-2xl relative text-white">
        <button
          onClick={dismissOffer}
          className="absolute top-3 right-3 text-white/70 hover:text-white p-1 rounded-full hover:bg-black/20"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2 text-xs font-bold text-[#2ECC71] uppercase tracking-wider mb-1">
          <Sparkles className="w-4 h-4" />
          <span>Priority Seat Offer Available!</span>
        </div>

        <h4 className="text-base font-extrabold truncate">{activeOffer.eventTitle}</h4>

        <div className="flex items-center justify-between text-xs my-2 text-blue-100">
          <span>Assigned Seat: <strong className="text-white text-sm">{activeOffer.seatLabel}</strong> ({activeOffer.categoryName})</span>
          <span>Price: <strong className="text-[#2ECC71] text-sm">${activeOffer.price?.toFixed(2)}</strong></span>
        </div>

        <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/20">
          <div className="flex items-center gap-1.5 text-xs text-[#F5B942] font-mono font-bold">
            <Timer className="w-4 h-4" />
            <span>Expires in {timerStr}</span>
          </div>

          <button
            onClick={handleClaim}
            className="px-4 py-2 rounded-xl bg-[#2ECC71] hover:bg-emerald-400 text-[#02050A] font-extrabold text-xs flex items-center gap-1.5 shadow-glow-green transition-all"
          >
            <span>Claim Seat</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default WaitlistOfferBanner;
