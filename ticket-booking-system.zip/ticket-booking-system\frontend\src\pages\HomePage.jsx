import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, Film, Music, Sparkles, Filter, Calendar, Zap } from 'lucide-react';
import api from '../services/api';
import EventCard from '../components/EventCard';

export const HomePage = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState('ALL'); // ALL, MOVIE, CONCERT
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchEvents();
  }, [filterType]);

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const typeParam = filterType !== 'ALL' ? `?type=${filterType}` : '';
      const res = await api.get(`/events${typeParam}`);
      if (res.data.success) {
        setEvents(res.data.events);
      }
    } catch (error) {
      console.error('Error loading events:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredEvents = events.filter((e) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      e.title.toLowerCase().includes(q) ||
      e.genre.toLowerCase().includes(q) ||
      e.venue?.name?.toLowerCase().includes(q)
    );
  });

  const heroEvent = events[0] || null;

  return (
    <div className="min-h-screen pb-16">
      {/* Cinematic Hero Section */}
      {heroEvent && (
        <div className="relative w-full h-[480px] lg:h-[560px] overflow-hidden bg-black flex items-end">
          <img
            src={heroEvent.bannerUrl || heroEvent.posterUrl}
            alt={heroEvent.title}
            className="absolute inset-0 w-full h-full object-cover opacity-45 scale-105 transform hover:scale-100 transition-transform duration-1000"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#02050A] via-[#02050A]/70 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-[#02050A] via-transparent to-transparent"></div>

          <div className="relative max-w-7xl mx-auto px-4 lg:px-8 pb-16 z-10 w-full">
            <div className="max-w-2xl space-y-4 animate-in fade-in slide-in-from-bottom-6 duration-700">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#044BDD]/30 border border-[#044BDD] text-[#C2D8DF] text-xs font-semibold backdrop-blur-md">
                <Sparkles className="w-3.5 h-3.5 text-[#2ECC71]" />
                <span>Featured Experience · Real-Time Seat Allocation</span>
              </div>

              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-none">
                {heroEvent.title}
              </h1>

              <p className="text-sm sm:text-base text-[#8D98A7] line-clamp-2 leading-relaxed">
                {heroEvent.description}
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <Link
                  to={`/events/${heroEvent.id}`}
                  className="px-6 py-3 rounded-2xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-bold text-sm shadow-cinematic transition-all hover:scale-105 flex items-center gap-2"
                >
                  <Film className="w-4 h-4" />
                  <span>Book Tickets Now</span>
                </Link>

                <div className="text-xs text-[#C2D8DF] flex items-center gap-2 bg-[#052053]/60 px-4 py-3 rounded-2xl border border-[#052053]">
                  <Calendar className="w-4 h-4 text-[#5C98A7]" />
                  <span>{new Date(heroEvent.eventDate).toLocaleDateString()} at {heroEvent.showTime}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Browse Section */}
      <div className="max-w-7xl mx-auto px-4 lg:px-8 pt-8">
        {/* Filter and Search Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8 bg-[#052053]/40 p-4 rounded-3xl border border-[#052053]">
          {/* Type Filter Buttons */}
          <div className="flex items-center gap-2 w-full md:w-auto">
            <button
              onClick={() => setFilterType('ALL')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                filterType === 'ALL'
                  ? 'bg-[#044BDD] text-white shadow-cinematic'
                  : 'bg-[#031435] text-[#8D98A7] hover:text-white'
              }`}
            >
              All Events
            </button>
            <button
              onClick={() => setFilterType('MOVIE')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                filterType === 'MOVIE'
                  ? 'bg-[#044BDD] text-white shadow-cinematic'
                  : 'bg-[#031435] text-[#8D98A7] hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              Movies
            </button>
            <button
              onClick={() => setFilterType('CONCERT')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                filterType === 'CONCERT'
                  ? 'bg-[#044BDD] text-white shadow-cinematic'
                  : 'bg-[#031435] text-[#8D98A7] hover:text-white'
              }`}
            >
              <Music className="w-3.5 h-3.5" />
              Concerts
            </button>
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#8D98A7]" />
            <input
              type="text"
              placeholder="Search by title, genre, venue..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-[#02050A] border border-[#0a2e73] rounded-xl text-xs text-white placeholder-[#8D98A7] focus:outline-none focus:border-[#044BDD]"
            />
          </div>
        </div>

        {/* Events Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div key={n} className="h-80 bg-[#052053]/40 rounded-3xl animate-pulse border border-[#052053]"></div>
            ))}
          </div>
        ) : filteredEvents.length === 0 ? (
          <div className="text-center py-20 bg-[#052053]/20 rounded-3xl border border-[#052053]">
            <Film className="w-12 h-12 text-[#8D98A7] mx-auto mb-3 opacity-50" />
            <h3 className="text-lg font-bold text-white">No Events Found</h3>
            <p className="text-xs text-[#8D98A7] mt-1">Try adjusting your filter or search query.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default HomePage;
