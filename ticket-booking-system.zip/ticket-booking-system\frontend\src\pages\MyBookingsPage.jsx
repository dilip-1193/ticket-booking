import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Ticket, Calendar, Clock, MapPin, XCircle, QrCode, AlertCircle, Sparkles } from 'lucide-react';
import api from '../services/api';
import TicketCard from '../components/TicketCard';

export const MyBookingsPage = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTicketBooking, setActiveTicketBooking] = useState(null);
  const [cancellingId, setCancellingId] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const res = await api.get('/bookings/my');
      if (res.data.success) {
        setBookings(res.data.bookings);
      }
    } catch (err) {
      console.error('Error fetching bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelBooking = async (bookingId) => {
    if (!window.confirm('Are you sure you want to cancel this booking? The seats will be automatically offered to waitlisted customers.')) {
      return;
    }

    setCancellingId(bookingId);
    setMessage('');
    setError('');

    try {
      const res = await api.post(`/bookings/${bookingId}/cancel`);
      if (res.data.success) {
        setMessage('Booking cancelled successfully! Seats were instantly offered to the waitlist queue.');
        fetchBookings();
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to cancel booking.');
    } finally {
      setCancellingId(null);
    }
  };

  return (
    <div className="min-h-screen py-12 px-4 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">My Bookings & Tickets</h1>
          <p className="text-xs text-[#8D98A7] mt-1">
            Manage your reservations, view digital QR codes, and cancel bookings with auto-waitlist reallocation.
          </p>
        </div>

        {message && (
          <div className="p-4 rounded-2xl bg-emerald-950/70 border border-emerald-500/80 text-emerald-200 text-xs flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#2ECC71]" />
            <span>{message}</span>
          </div>
        )}

        {error && (
          <div className="p-4 rounded-2xl bg-red-950/70 border border-red-500/80 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400" />
            <span>{error}</span>
          </div>
        )}

        {loading ? (
          <div className="space-y-4">
            {[1, 2].map((n) => (
              <div key={n} className="h-36 bg-[#052053]/40 rounded-3xl animate-pulse border border-[#052053]"></div>
            ))}
          </div>
        ) : bookings.length === 0 ? (
          <div className="text-center py-20 bg-[#052053]/20 rounded-3xl border border-[#052053]">
            <Ticket className="w-12 h-12 text-[#8D98A7] mx-auto mb-3 opacity-50" />
            <h3 className="text-lg font-bold text-white">No Bookings Found</h3>
            <p className="text-xs text-[#8D98A7] mt-1 mb-6">You have not booked any movie or concert tickets yet.</p>
            <Link
              to="/"
              className="px-6 py-3 rounded-2xl bg-[#044BDD] text-white text-xs font-bold shadow-cinematic"
            >
              Browse Events
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {bookings.map((booking) => {
              const event = booking.event || {};
              const seats = booking.bookingSeats || [];
              const isCancelled = booking.status === 'CANCELLED';

              return (
                <div
                  key={booking.id}
                  className={`bg-[#052053]/40 border rounded-3xl p-6 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6 ${
                    isCancelled ? 'border-[#0a2e73] opacity-60' : 'border-[#052053] hover:border-[#044BDD]'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={event.posterUrl}
                      alt={event.title}
                      className="w-16 sm:w-20 aspect-[3/4] object-cover rounded-xl border border-[#0a2e73] shrink-0"
                    />

                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                            isCancelled
                              ? 'bg-red-950/60 text-red-400 border-red-500/50'
                              : 'bg-emerald-950/60 text-[#2ECC71] border-[#2ECC71]/50'
                          }`}
                        >
                          {booking.status}
                        </span>
                        <span className="font-mono text-xs text-[#5C98A7]">{booking.bookingReference}</span>
                      </div>

                      <h3 className="text-base font-bold text-white leading-tight">{event.title}</h3>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-[#8D98A7]">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-[#5C98A7]" />
                          {new Date(event.eventDate).toLocaleDateString()}
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-[#5C98A7]" />
                          {event.showTime}
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-[#5C98A7]" />
                          {event.venue?.name}
                        </span>
                      </div>

                      <div className="text-xs text-[#C2D8DF] pt-1">
                        <span>Seats: </span>
                        <strong className="text-white font-bold">
                          {seats.map((s) => s.seatLabel).join(', ')}
                        </strong>
                        <span className="text-[#8D98A7] ml-2 font-mono">(${booking.totalAmount.toFixed(2)})</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-3 self-end md:self-center">
                    {!isCancelled && (
                      <>
                        <button
                          onClick={() => setActiveTicketBooking(booking)}
                          className="px-4 py-2.5 rounded-xl bg-[#044BDD] hover:bg-[#0337A0] text-white text-xs font-bold shadow-cinematic transition-all flex items-center gap-2"
                        >
                          <QrCode className="w-3.5 h-3.5" />
                          <span>View Ticket QR</span>
                        </button>

                        <button
                          onClick={() => handleCancelBooking(booking.id)}
                          disabled={cancellingId === booking.id}
                          className="px-4 py-2.5 rounded-xl bg-red-950/40 hover:bg-red-950 text-red-400 hover:text-red-200 border border-red-500/30 text-xs font-semibold transition-colors flex items-center gap-1.5"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>{cancellingId === booking.id ? 'Cancelling...' : 'Cancel'}</span>
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Ticket Modal */}
      {activeTicketBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative max-w-md w-full">
            <button
              onClick={() => setActiveTicketBooking(null)}
              className="absolute -top-12 right-0 text-white bg-[#052053] p-2 rounded-full border border-[#044BDD]"
            >
              ✕ Close
            </button>
            <TicketCard booking={activeTicketBooking} />
          </div>
        </div>
      )}
    </div>
  );
};

export default MyBookingsPage;
