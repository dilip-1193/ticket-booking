import express from 'express';
import { venueController } from '../controllers/venueController.js';
import { authenticate, requireRole } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', venueController.getAllVenues);
router.get('/:id', venueController.getVenueById);
router.post('/', authenticate, requireRole('ADMIN'), venueController.createVenue);
router.delete('/:id', authenticate, requireRole('ADMIN'), venueController.deleteVenue);

export default router;
