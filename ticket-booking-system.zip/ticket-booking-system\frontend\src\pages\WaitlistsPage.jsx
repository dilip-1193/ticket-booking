import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Clock, Sparkles, ArrowRight, ShieldCheck, Timer } from 'lucide-react';
import api from '../services/api';

export const WaitlistsPage = () => {
  const [waitlists, setWaitlists] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWaitlists();
  }, []);

  const fetchWaitlists = async () => {
    try {
      const res = await api.get('/waitlist/my');
      if (res.data.success) {
        setWaitlists(res.data.waitlists);
      }
    } catch (error) {
      console.error('Error loading waitlists:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen py-12 px-4 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">My Waitlists & Offers</h1>
          <p className="text-xs text-[#8D98A7] mt-1">
            Track your queue positions for sold-out events and claim time-limited seat offers as cancellations occur.
          </p>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2].map((n) => (
              <div key={n} className="h-32 bg-[#052053]/40 rounded-3xl animate-pulse border border-[#052053]"></div>
            ))}
          </div>
        ) : waitlists.length === 0 ? (
          <div className="text-center py-20 bg-[#052053]/20 rounded-3xl border border-[#052053]">
            <Clock className="w-12 h-12 text-[#8D98A7] mx-auto mb-3 opacity-50" />
            <h3 className="text-lg font-bold text-white">No Active Waitlists</h3>
            <p className="text-xs text-[#8D98A7] mt-1 mb-6">
              When an event or seat category sells out, you can join the priority queue to automatically receive first offers upon cancellation.
            </p>
            <Link
              to="/"
              className="px-6 py-3 rounded-2xl bg-[#044BDD] text-white text-xs font-bold shadow-cinematic"
            >
              Browse Events
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {waitlists.map((entry) => {
              const event = entry.event || {};
              const activeOffer = entry.offers?.[0] || null;
              const isOffered = entry.status === 'OFFERED' && activeOffer;

              return (
                <div
                  key={entry.id}
                  className={`bg-[#052053]/40 border rounded-3xl p-6 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6 ${
                    isOffered
                      ? 'border-[#2ECC71] shadow-glow-green bg-gradient-to-r from-[#052053] to-emerald-950/30'
                      : 'border-[#052053]'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={event.posterUrl}
                      alt={event.title}
                      className="w-16 aspect-[3/4] object-cover rounded-xl border border-[#0a2e73] shrink-0"
                    />

                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border ${
                            isOffered
                              ? 'bg-[#2ECC71] text-[#02050A] border-[#2ECC71] animate-pulse'
                              : entry.status === 'CLAIMED'
                              ? 'bg-blue-900/60 text-blue-300 border-blue-500/40'
                              : 'bg-amber-950/60 text-amber-300 border-amber-500/50'
                          }`}
                        >
                          {isOffered ? 'OFFER READY!' : entry.status}
                        </span>

                        {!isOffered && entry.status === 'WAITING' && (
                          <span className="text-xs font-bold text-[#5C98A7]">
                            Queue Position #{entry.position}
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-bold text-white leading-tight">{event.title}</h3>
                      <p className="text-xs text-[#8D98A7]">
                        Category: <strong className="text-white">{entry.seatCategoryName}</strong> · Joined on{' '}
                        {new Date(entry.createdAt).toLocaleDateString()}
                      </p>

                      {isOffered && (
                        <div className="text-xs text-[#2ECC71] font-semibold flex items-center gap-1.5 pt-1">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>
                            Seat {activeOffer.showSeat?.seatLabel} assigned! Limited time remaining to complete claim.
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Action */}
                  <div className="self-end md:self-center">
                    {isOffered ? (
                      <Link
                        to={`/waitlist/claim/${activeOffer.token}`}
                        className="px-6 py-3 rounded-2xl bg-[#2ECC71] hover:bg-emerald-400 text-[#02050A] font-extrabold text-xs shadow-glow-green transition-all flex items-center gap-2"
                      >
                        <span>Claim Seat Now</span>
                        <ArrowRight className="w-4 h-4" />
                      </Link>
                    ) : (
                      <div className="text-xs text-[#8D98A7] bg-[#031435] px-4 py-2 rounded-xl border border-[#0a2e73] flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-[#F5B942]" />
                        <span>Awaiting cancellations</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default WaitlistsPage;
