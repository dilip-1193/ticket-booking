import React, { useState } from 'react';
import { X, Clock, ShieldCheck, Sparkles } from 'lucide-react';
import api from '../services/api';

export const WaitlistModal = ({ event, isOpen, onClose, onJoined }) => {
  const [category, setCategory] = useState('Premium');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen || !event) return null;

  const handleJoin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await api.post(`/waitlist/events/${event.id}/join`, {
        seatCategoryName: category,
      });

      if (res.data.success) {
        if (onJoined) onJoined(res.data.entry);
        onClose();
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to join waitlist. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#052053] border border-[#044BDD]/50 rounded-3xl p-6 relative shadow-2xl animate-in fade-in zoom-in duration-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#8D98A7] hover:text-white p-2 rounded-full hover:bg-[#0a2e73] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Join Priority Waitlist</h3>
            <p className="text-xs text-[#8D98A7]">{event.title}</p>
          </div>
        </div>

        <p className="text-xs text-[#C2D8DF] mb-5 leading-relaxed">
          When seats become available due to cancellations, tickets are automatically offered to waitlisted customers in First-In-First-Out order with a time-limited claim link.
        </p>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-950/50 border border-red-500/50 text-red-300 text-xs font-medium">
            {error}
          </div>
        )}

        <form onSubmit={handleJoin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#8D98A7] uppercase mb-2">
              Select Preferred Category
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setCategory('Premium')}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  category === 'Premium'
                    ? 'bg-[#044BDD] border-white text-white shadow-glow-blue'
                    : 'bg-[#031435] border-[#0a2e73] text-[#C2D8DF] hover:border-[#044BDD]'
                }`}
              >
                <div className="font-bold text-sm">Premium</div>
                <div className="text-[11px] opacity-80">${event.premiumPrice?.toFixed(2)}</div>
              </button>

              <button
                type="button"
                onClick={() => setCategory('Standard')}
                className={`p-3 rounded-2xl border text-left transition-all ${
                  category === 'Standard'
                    ? 'bg-[#044BDD] border-white text-white shadow-glow-blue'
                    : 'bg-[#031435] border-[#0a2e73] text-[#C2D8DF] hover:border-[#044BDD]'
                }`}
              >
                <div className="font-bold text-sm">Standard</div>
                <div className="text-[11px] opacity-80">${event.standardPrice?.toFixed(2)}</div>
              </button>
            </div>
          </div>

          <div className="bg-[#031435] p-3 rounded-xl border border-[#0a2e73] flex items-center gap-2 text-[11px] text-[#5C98A7]">
            <ShieldCheck className="w-4 h-4 text-[#2ECC71] shrink-0" />
            <span>You will receive an instant email and in-app alert when offered a seat.</span>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-4 rounded-xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-bold text-sm shadow-cinematic transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? 'Joining Waitlist...' : `Join ${category} Waitlist`}
          </button>
        </form>
      </div>
    </div>
  );
};

export default WaitlistModal;
