import express from 'express';
import { waitlistController } from '../controllers/waitlistController.js';
import { authenticate } from '../middleware/authMiddleware.js';

const router = express.Router();

// Public offer inspection by token (contains token verification)
router.get('/offers/:token', waitlistController.getOfferDetails);

// Protected actions
router.post('/offers/:token/claim', authenticate, waitlistController.claimOffer);
router.get('/my', authenticate, waitlistController.getMyWaitlists);
router.post('/events/:eventId/join', authenticate, waitlistController.joinWaitlist);

export default router;
