import React, { useState } from 'react';
import { Plus, Shield, Check, Trash2 } from 'lucide-react';
import api from '../services/api';

export const VenueBuilder = ({ onVenueCreated }) => {
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [totalRows, setTotalRows] = useState(6);
  const [seatsPerRow, setSeatsPerRow] = useState(10);
  const [premiumRowsCount, setPremiumRowsCount] = useState(2);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const res = await api.post('/venues', {
        name,
        city,
        address,
        totalRows: Number(totalRows),
        seatsPerRow: Number(seatsPerRow),
        premiumRowsCount: Number(premiumRowsCount),
      });

      if (res.data.success) {
        setSuccess(`Venue "${name}" with ${totalRows * seatsPerRow} seats created successfully!`);
        setName('');
        setCity('');
        setAddress('');
        if (onVenueCreated) onVenueCreated(res.data.venue);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create venue.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#052053]/50 border border-[#052053] rounded-3xl p-6 lg:p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-2xl bg-[#044BDD]/20 border border-[#044BDD]/40 flex items-center justify-center text-[#044BDD]">
          <Plus className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white">Interactive Venue & Seating Builder</h2>
          <p className="text-xs text-[#8D98A7]">Design new theater halls, concert arenas, and seat layouts</p>
        </div>
      </div>

      {error && (
        <div className="p-3 mb-4 rounded-xl bg-red-950/50 border border-red-500/50 text-red-300 text-xs">
          {error}
        </div>
      )}

      {success && (
        <div className="p-3 mb-4 rounded-xl bg-emerald-950/50 border border-emerald-500/50 text-emerald-300 text-xs">
          {success}
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Controls */}
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#8D98A7] mb-1.5">Venue Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Dolby Cinema Auditorium 1"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#044BDD]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#8D98A7] mb-1.5">City</label>
              <input
                type="text"
                required
                placeholder="e.g. San Francisco"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#044BDD]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8D98A7] mb-1.5">Street Address</label>
              <input
                type="text"
                required
                placeholder="e.g. 500 Market St"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#044BDD]"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#8D98A7] mb-1.5">Total Rows (A-Z)</label>
              <input
                type="number"
                min="1"
                max="12"
                value={totalRows}
                onChange={(e) => setTotalRows(Math.min(12, Math.max(1, Number(e.target.value))))}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#044BDD]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8D98A7] mb-1.5">Seats Per Row</label>
              <input
                type="number"
                min="4"
                max="16"
                value={seatsPerRow}
                onChange={(e) => setSeatsPerRow(Math.min(16, Math.max(4, Number(e.target.value))))}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#044BDD]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#8D98A7] mb-1.5">Premium Front Rows</label>
              <input
                type="number"
                min="0"
                max={totalRows}
                value={premiumRowsCount}
                onChange={(e) => setPremiumRowsCount(Math.min(totalRows, Math.max(0, Number(e.target.value))))}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-[#044BDD]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-bold text-sm shadow-cinematic transition-all disabled:opacity-50 mt-4 flex items-center justify-center gap-2"
          >
            {loading ? 'Creating Venue...' : 'Save Venue & Generate Seats'}
          </button>
        </div>

        {/* Live Grid Preview */}
        <div className="bg-[#02050A] border border-[#0a2e73] rounded-2xl p-4 flex flex-col items-center justify-center">
          <div className="w-3/4 h-2 bg-gradient-to-r from-transparent via-[#044BDD] to-transparent rounded-full mb-6"></div>
          <span className="text-[10px] uppercase tracking-widest text-[#5C98A7] mb-4">Stage / Screen Live Preview</span>

          <div className="flex flex-col gap-1.5 max-h-60 overflow-y-auto w-full items-center p-2">
            {Array.from({ length: totalRows }).map((_, r) => {
              const rowLetter = String.fromCharCode(65 + r);
              const isPremium = r < premiumRowsCount;

              return (
                <div key={r} className="flex items-center gap-1.5">
                  <span className="w-4 text-[10px] text-[#8D98A7] font-bold">{rowLetter}</span>
                  <div className="flex gap-1">
                    {Array.from({ length: seatsPerRow }).map((_, c) => (
                      <div
                        key={c}
                        className={`w-4 h-4 rounded text-[8px] flex items-center justify-center font-bold ${
                          isPremium
                            ? 'bg-[#044BDD] text-white border border-[#5C98A7]'
                            : 'bg-[#052053] text-[#C2D8DF] border border-[#0a2e73]'
                        }`}
                      >
                        {c + 1}
                      </div>
                    ))}
                  </div>
                  <span className="text-[9px] text-gray-500 ml-1">{isPremium ? 'Prem' : 'Std'}</span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center gap-4 text-[11px] text-[#8D98A7] mt-4 pt-3 border-t border-[#0a2e73] w-full justify-center">
            <span>Total Seats: <strong className="text-white">{totalRows * seatsPerRow}</strong></span>
            <span>Premium: <strong className="text-[#044BDD]">{premiumRowsCount * seatsPerRow}</strong></span>
            <span>Standard: <strong className="text-[#5C98A7]">{(totalRows - premiumRowsCount) * seatsPerRow}</strong></span>
          </div>
        </div>
      </form>
    </div>
  );
};

export default VenueBuilder;
