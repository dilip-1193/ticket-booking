import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import createApp from './app.js';
import { ENV } from './config/env.js';
import { initSocket } from './sockets/socketHandler.js';
import { startHoldTtlWorker, stopHoldTtlWorker } from './jobs/holdTtlWorker.js';
import { startWaitlistOfferWorker, stopWaitlistOfferWorker } from './jobs/waitlistOfferWorker.js';
import { logger } from './utils/logger.js';
import prisma from './config/db.js';

const app = createApp();
const server = http.createServer(app);

// Setup Socket.IO with CORS
const io = new SocketIOServer(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

initSocket(io);

// Start background workers
startHoldTtlWorker(4000);
startWaitlistOfferWorker(4000);

const PORT = ENV.PORT || 5000;

server.listen(PORT, () => {
  logger.info(`====================================================`);
  logger.info(`🚀 Ticket Booking Backend running on port ${PORT}`);
  logger.info(`📡 Real-time WebSockets active`);
  logger.info(`⏳ Seat Hold TTL Worker active (${ENV.SEAT_HOLD_TTL_MINUTES}m TTL)`);
  logger.info(`⏳ Waitlist Offer Worker active (${ENV.WAITLIST_OFFER_TTL_MINUTES}m TTL)`);
  logger.info(`🌐 Environment: ${ENV.NODE_ENV}`);
  logger.info(`====================================================`);
});

// Graceful shutdown
const handleShutdown = async () => {
  logger.info('Shutting down server gracefully...');
  stopHoldTtlWorker();
  stopWaitlistOfferWorker();
  await prisma.$disconnect();
  server.close(() => {
    logger.info('Server closed.');
    process.exit(0);
  });
};

process.on('SIGTERM', handleShutdown);
process.on('SIGINT', handleShutdown);

export { server, io };
