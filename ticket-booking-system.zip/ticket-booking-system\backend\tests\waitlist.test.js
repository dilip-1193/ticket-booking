import prisma from '../src/config/db.js';
import { bookingService } from '../src/services/bookingService.js';
import { waitlistService } from '../src/services/waitlistService.js';
import { seatService } from '../src/services/seatService.js';

async function runWaitlistTest() {
  console.log('\n======================================================');
  console.log('🧪 RUNNING TEST: Waitlist Auto-Assignment on Cancellation');
  console.log('======================================================');

  // Fetch event and users
  const event = await prisma.event.findFirst();
  const [customer1, customer2, customer3] = await prisma.user.findMany({
    where: { role: 'CUSTOMER' },
  });

  // Clean test waitlist entries for this event to start fresh
  await prisma.waitlistOffer.deleteMany({ where: { eventId: event.id } });
  await prisma.waitlistEntry.deleteMany({ where: { eventId: event.id } });

  // Find an available seat
  const seat = await prisma.showSeat.findFirst({
    where: { eventId: event.id, status: 'AVAILABLE', categoryName: 'Premium' },
  });

  if (!seat) throw new Error('Need available Premium seat for test');

  console.log(`1️⃣ Customer 1 (${customer1.name}) books seat ${seat.seatLabel}...`);
  await seatService.holdSeats(event.id, [seat.id], customer1.id);
  const { booking } = await bookingService.createBooking(event.id, [seat.id], customer1.id);
  console.log(`   ✅ Booking created: ${booking.bookingReference} for Seat ${seat.seatLabel}`);

  console.log(`2️⃣ Customer 2 (${customer2.name}) joins waitlist for Premium seats...`);
  const wl2 = await waitlistService.joinWaitlist(event.id, customer2.id, 'Premium');
  console.log(`   ✅ Customer 2 waitlist registered: Queue Position #${wl2.entry.position}`);

  console.log(`3️⃣ Customer 3 (${customer3.name}) joins waitlist for Premium seats...`);
  const wl3 = await waitlistService.joinWaitlist(event.id, customer3.id, 'Premium');
  console.log(`   ✅ Customer 3 waitlist registered: Queue Position #${wl3.entry.position}`);

  console.log(`4️⃣ Customer 1 cancels booking ${booking.bookingReference}...`);
  await bookingService.cancelBooking(booking.id, customer1.id, 'CUSTOMER');
  console.log('   ✅ Booking cancelled. System automatically triggered waitlist processing.');

  // Verify Customer 2 (FIFO head) received offer
  const offerC2 = await prisma.waitlistOffer.findFirst({
    where: { eventId: event.id, userId: customer2.id, status: 'PENDING' },
    include: { showSeat: true },
  });

  if (offerC2 && offerC2.showSeatId === seat.id) {
    console.log(`   ✅ PASS: Customer 2 (Position #1) was automatically assigned Seat ${offerC2.showSeat.seatLabel}!`);
    console.log(`      Offer Token: ${offerC2.token}, Expires: ${offerC2.expiresAt.toISOString()}`);
  } else {
    throw new Error('   ❌ FAIL: Customer 2 did not receive expected waitlist offer.');
  }

  // Customer 3 should still be in WAITING state
  const entryC3 = await prisma.waitlistEntry.findFirst({
    where: { eventId: event.id, userId: customer3.id },
  });
  if (entryC3.status === 'WAITING') {
    console.log('   ✅ PASS: Customer 3 remains in WAITING status (next in line).');
  } else {
    throw new Error('   ❌ FAIL: Customer 3 state incorrect.');
  }

  // Customer 2 claims the offer
  console.log(`5️⃣ Customer 2 claims their time-limited offer...`);
  const claimRes = await waitlistService.claimWaitlistOffer(offerC2.token, customer2.id);
  console.log(`   ✅ PASS: Customer 2 confirmed booking! Ref: ${claimRes.booking.bookingReference}`);

  // Verify seat is now BOOKED by Customer 2
  const finalSeat = await prisma.showSeat.findUnique({ where: { id: seat.id } });
  if (finalSeat.status === 'BOOKED') {
    console.log(`   ✅ PASS: Database seat status confirmed as BOOKED.`);
  } else {
    throw new Error(`   ❌ FAIL: Expected BOOKED, got ${finalSeat.status}`);
  }

  console.log('\n🎉 Waitlist Auto-Assignment & Offer Claim Test PASSED!\n');
}

runWaitlistTest()
  .catch((err) => {
    console.error('❌ Test failed:', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
