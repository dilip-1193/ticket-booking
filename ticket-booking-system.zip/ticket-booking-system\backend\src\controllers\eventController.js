import prisma from '../config/db.js';

export const eventController = {
  async getAllEvents(req, res, next) {
    try {
      const { type, genre, search, date } = req.query;

      const where = {};

      if (type) {
        where.type = type.toUpperCase();
      }

      if (genre) {
        where.genre = { contains: genre };
      }

      if (search) {
        where.OR = [
          { title: { contains: search } },
          { description: { contains: search } },
        ];
      }

      if (date) {
        const startOfDay = new Date(date);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(date);
        endOfDay.setHours(23, 59, 59, 999);
        where.eventDate = {
          gte: startOfDay,
          lte: endOfDay,
        };
      }

      const events = await prisma.event.findMany({
        where,
        include: {
          venue: { select: { id: true, name: true, city: true, address: true } },
          organiser: { select: { id: true, name: true } },
          _count: {
            select: {
              showSeats: true,
              bookings: true,
            },
          },
        },
        orderBy: { eventDate: 'asc' },
      });

      // Augment each event with available seats count and sold-out flags
      const eventsWithStats = await Promise.all(
        events.map(async (event) => {
          const availableSeatsCount = await prisma.showSeat.count({
            where: {
              eventId: event.id,
              status: 'AVAILABLE',
            },
          });

          const totalSeats = event._count.showSeats;
          const isSoldOut = totalSeats > 0 && availableSeatsCount === 0;

          return {
            ...event,
            totalSeats,
            availableSeatsCount,
            isSoldOut,
          };
        })
      );

      res.json({ success: true, events: eventsWithStats });
    } catch (error) {
      next(error);
    }
  },

  async getEventById(req, res, next) {
    try {
      const { id } = req.params;
      const event = await prisma.event.findUnique({
        where: { id },
        include: {
          venue: {
            include: {
              seatCategories: true,
            },
          },
          organiser: { select: { id: true, name: true, email: true } },
        },
      });

      if (!event) {
        return res.status(404).json({ success: false, message: 'Event not found' });
      }

      // Compute category level availability
      const categoryStats = await prisma.showSeat.groupBy({
        by: ['categoryName', 'status'],
        where: { eventId: id },
        _count: { id: true },
      });

      const categories = {};
      for (const stat of categoryStats) {
        if (!categories[stat.categoryName]) {
          categories[stat.categoryName] = { total: 0, available: 0, held: 0, booked: 0, offered: 0 };
        }
        categories[stat.categoryName].total += stat._count.id;
        if (stat.status === 'AVAILABLE') categories[stat.categoryName].available += stat._count.id;
        if (stat.status === 'HELD') categories[stat.categoryName].held += stat._count.id;
        if (stat.status === 'BOOKED') categories[stat.categoryName].booked += stat._count.id;
        if (stat.status === 'OFFERED') categories[stat.categoryName].offered += stat._count.id;
      }

      res.json({
        success: true,
        event: {
          ...event,
          categoryAvailability: categories,
        },
      });
    } catch (error) {
      next(error);
    }
  },

  /**
   * Organiser or Admin creates a new Event and automatically initializes ShowSeats
   */
  async createEvent(req, res, next) {
    try {
      const {
        title,
        description,
        type = 'MOVIE',
        genre,
        durationMinutes = 120,
        posterUrl,
        bannerUrl,
        venueId,
        eventDate,
        showTime = '19:30',
        premiumPrice = 350.0,
        standardPrice = 200.0,
      } = req.body;

      if (!title || !description || !venueId || !eventDate) {
        return res.status(400).json({
          success: false,
          message: 'Title, description, venue, and event date are required',
        });
      }

      const venue = await prisma.venue.findUnique({
        where: { id: venueId },
        include: {
          seats: {
            include: { category: true },
          },
        },
      });

      if (!venue) {
        return res.status(404).json({ success: false, message: 'Venue not found' });
      }

      const parsedDate = new Date(eventDate);
      const organiserId = req.user.id;

      const event = await prisma.$transaction(async (tx) => {
        const createdEvent = await tx.event.create({
          data: {
            title: title.trim(),
            description: description.trim(),
            type: type.toUpperCase(),
            genre: genre?.trim() || 'General',
            durationMinutes: parseInt(durationMinutes, 10) || 120,
            posterUrl: posterUrl || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800&auto=format&fit=crop&q=80',
            bannerUrl: bannerUrl || posterUrl || 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1600&auto=format&fit=crop&q=80',
            venueId,
            organiserId,
            eventDate: parsedDate,
            showTime,
            premiumPrice: parseFloat(premiumPrice) || 350.0,
            standardPrice: parseFloat(standardPrice) || 200.0,
            status: 'UPCOMING',
          },
        });

        // Instantiate ShowSeat records for this event
        const showSeatsData = venue.seats.map((seat) => {
          const isPremium = seat.category.name.toLowerCase().includes('prem');
          const price = isPremium ? parseFloat(premiumPrice) : parseFloat(standardPrice);

          return {
            eventId: createdEvent.id,
            seatId: seat.id,
            row: seat.row,
            number: seat.number,
            seatLabel: seat.seatLabel,
            categoryName: seat.category.name,
            price,
            status: 'AVAILABLE',
          };
        });

        for (const showSeat of showSeatsData) {
          await tx.showSeat.create({ data: showSeat });
        }

        return createdEvent;
      });

      const fullEvent = await prisma.event.findUnique({
        where: { id: event.id },
        include: { venue: true, _count: { select: { showSeats: true } } },
      });

      res.status(201).json({
        success: true,
        message: 'Event created and show seats initialized successfully',
        event: fullEvent,
      });
    } catch (error) {
      next(error);
    }
  },

  async deleteEvent(req, res, next) {
    try {
      const { id } = req.params;
      const event = await prisma.event.findUnique({ where: { id } });

      if (!event) {
        return res.status(404).json({ success: false, message: 'Event not found' });
      }

      if (event.organiserId !== req.user.id && req.user.role !== 'ADMIN') {
        return res.status(403).json({ success: false, message: 'Unauthorized to delete this event' });
      }

      await prisma.event.delete({ where: { id } });
      res.json({ success: true, message: 'Event deleted successfully' });
    } catch (error) {
      next(error);
    }
  },
};
