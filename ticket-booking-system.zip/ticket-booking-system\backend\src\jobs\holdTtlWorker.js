import { seatService } from '../services/seatService.js';
import { logger } from '../utils/logger.js';

let intervalHandle = null;

export const startHoldTtlWorker = (intervalMs = 5000) => {
  logger.info(`Starting Seat Hold TTL Worker (Interval: ${intervalMs}ms)...`);

  intervalHandle = setInterval(async () => {
    try {
      await seatService.autoReleaseExpiredHolds();
    } catch (error) {
      logger.error('Error in Hold TTL Worker loop:', error);
    }
  }, intervalMs);
};

export const stopHoldTtlWorker = () => {
  if (intervalHandle) {
    clearInterval(intervalHandle);
    intervalHandle = null;
    logger.info('Stopped Seat Hold TTL Worker');
  }
};
