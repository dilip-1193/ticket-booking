import express from 'express';
import { seatController } from '../controllers/seatController.js';
import { authenticate } from '../middleware/authMiddleware.js';

const router = express.Router();

// Publicly viewable seat map (optionally attaches user info if authenticated)
router.get('/:eventId/seats', seatController.getSeats);

// Protected seat hold and release actions
router.post('/:eventId/hold', authenticate, seatController.holdSeats);
router.post('/:eventId/release-hold', authenticate, seatController.releaseHold);

export default router;
