import crypto from 'crypto';
import prisma from '../config/db.js';
import { qrService } from './qrService.js';
import { emailService } from './emailService.js';
import { waitlistService } from './waitlistService.js';
import { broadcastSeatUpdate } from '../sockets/socketHandler.js';
import { logger } from '../utils/logger.js';

export const bookingService = {
  /**
   * Complete booking from active seat holds
   */
  async createBooking(eventId, showSeatIds, userId) {
    if (!showSeatIds || !Array.isArray(showSeatIds) || showSeatIds.length === 0) {
      const err = new Error('No seats specified for checkout');
      err.statusCode = 400;
      throw err;
    }

    const now = new Date();

    // Execute atomic checkout transaction
    const result = await prisma.$transaction(async (tx) => {
      // 1. Fetch event
      const event = await tx.event.findUnique({
        where: { id: eventId },
        include: { venue: true },
      });

      if (!event) {
        const err = new Error('Event not found');
        err.statusCode = 404;
        throw err;
      }

      // 2. Verify all seats are currently held by this user and not expired
      const seats = await tx.showSeat.findMany({
        where: {
          id: { in: showSeatIds },
          eventId,
        },
      });

      if (seats.length !== showSeatIds.length) {
        const err = new Error('One or more requested seats could not be found');
        err.statusCode = 404;
        throw err;
      }

      for (const seat of seats) {
        if (seat.status !== 'HELD' || seat.heldByUserId !== userId) {
          const err = new Error(`Seat ${seat.seatLabel} is not held by you or has already been booked.`);
          err.statusCode = 409;
          throw err;
        }

        if (seat.holdExpiresAt && new Date(seat.holdExpiresAt) < now) {
          const err = new Error(`Your hold on seat ${seat.seatLabel} has expired. Please select your seats again.`);
          err.statusCode = 410;
          throw err;
        }
      }

      // 3. Calculate total amount
      const totalAmount = seats.reduce((sum, seat) => sum + seat.price, 0);

      // 4. Generate unique booking reference
      const refSuffix = crypto.randomBytes(3).toString('hex').toUpperCase();
      const bookingReference = `TBS-${new Date().getFullYear()}-${refSuffix}`;

      // 5. Update ShowSeats to BOOKED
      for (const seat of seats) {
        await tx.showSeat.update({
          where: { id: seat.id },
          data: {
            status: 'BOOKED',
            heldByUserId: null,
            holdExpiresAt: null,
            version: { increment: 1 },
          },
        });
      }

      // 6. Update SeatHolds to CONVERTED
      await tx.seatHold.updateMany({
        where: {
          eventId,
          userId,
          showSeatId: { in: showSeatIds },
          status: 'ACTIVE',
        },
        data: { status: 'CONVERTED' },
      });

      // 7. Create Booking
      const booking = await tx.booking.create({
        data: {
          bookingReference,
          userId,
          eventId,
          totalAmount,
          status: 'CONFIRMED',
          bookingSeats: {
            create: seats.map((seat) => ({
              showSeatId: seat.id,
              seatLabel: seat.seatLabel,
              categoryName: seat.categoryName,
              price: seat.price,
            })),
          },
        },
        include: {
          bookingSeats: true,
          event: { include: { venue: true } },
          user: true,
        },
      });

      // 8. Create Tickets
      for (let i = 0; i < seats.length; i++) {
        await tx.ticket.create({
          data: {
            bookingId: booking.id,
            ticketNumber: `TKT-${bookingReference}-${i + 1}`,
          },
        });
      }

      return { booking, event, seats };
    });

    // 9. Generate QR Code with booking reference & ticket metadata
    const qrDataUrl = await qrService.generateTicketQR(result.booking.bookingReference, {
      eventTitle: result.event.title,
      seats: result.seats.map((s) => s.seatLabel),
      customerName: result.booking.user.name,
    });

    // 10. Update booking with QR data
    const finalBooking = await prisma.booking.update({
      where: { id: result.booking.id },
      data: { qrCodeData: qrDataUrl },
      include: {
        bookingSeats: true,
        event: { include: { venue: true } },
        tickets: true,
        user: { select: { id: true, name: true, email: true } },
      },
    });

    // 11. Broadcast real-time seat update to all clients
    broadcastSeatUpdate(eventId, {
      type: 'SEAT_BOOKED',
      eventId,
      seatIds: showSeatIds,
    });

    // 12. Send email confirmation with QR code
    emailService
      .sendBookingConfirmation(finalBooking.user, finalBooking, finalBooking.event, finalBooking.bookingSeats)
      .catch((err) => {
        logger.error('Failed to send confirmation email:', err);
      });

    logger.info(`Booking created successfully: ${finalBooking.bookingReference} for user ${userId}`);

    return {
      success: true,
      message: 'Booking confirmed successfully!',
      booking: finalBooking,
    };
  },

  /**
   * Get user booking history
   */
  async getUserBookings(userId) {
    return await prisma.booking.findMany({
      where: { userId },
      include: {
        event: {
          include: { venue: true },
        },
        bookingSeats: true,
        tickets: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  },

  /**
   * Get single booking details by ID
   */
  async getBookingById(bookingId, userId, userRole) {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        event: {
          include: { venue: true },
        },
        bookingSeats: true,
        tickets: true,
        user: { select: { id: true, name: true, email: true } },
      },
    });

    if (!booking) {
      const err = new Error('Booking not found');
      err.statusCode = 404;
      throw err;
    }

    if (booking.userId !== userId && userRole !== 'ADMIN' && userRole !== 'ORGANISER') {
      const err = new Error('Unauthorized to view this booking');
      err.statusCode = 403;
      throw err;
    }

    return booking;
  },

  /**
   * Cancel booking and automatically reallocate seats to category waitlist
   */
  async cancelBooking(bookingId, userId, userRole) {
    const booking = await prisma.booking.findUnique({
      where: { id: bookingId },
      include: {
        bookingSeats: {
          include: { showSeat: true },
        },
        event: true,
      },
    });

    if (!booking) {
      const err = new Error('Booking not found');
      err.statusCode = 404;
      throw err;
    }

    if (booking.userId !== userId && userRole !== 'ADMIN') {
      const err = new Error('Unauthorized to cancel this booking');
      err.statusCode = 403;
      throw err;
    }

    if (booking.status === 'CANCELLED') {
      const err = new Error('Booking is already cancelled');
      err.statusCode = 400;
      throw err;
    }

    // Atomically cancel booking
    await prisma.booking.update({
      where: { id: bookingId },
      data: { status: 'CANCELLED' },
    });

    logger.info(`Booking ${booking.bookingReference} cancelled by user ${userId}. Processing waitlist reallocations.`);

    // Trigger waitlist auto-assignment for each cancelled seat
    for (const item of booking.bookingSeats) {
      await waitlistService.processSeatFreed(booking.eventId, item.categoryName, item.showSeatId);
    }

    return {
      success: true,
      message: 'Booking cancelled successfully. Seats have been automatically offered to eligible waitlisted customers.',
      bookingId,
    };
  },
};
