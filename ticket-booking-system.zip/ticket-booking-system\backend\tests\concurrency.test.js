import prisma from '../src/config/db.js';
import { seatService } from '../src/services/seatService.js';

async function runConcurrencyTest() {
  console.log('\n======================================================');
  console.log('🧪 RUNNING TEST: Simultaneous Seat Selection Concurrency');
  console.log('======================================================');

  // 1. Get an active event and find an AVAILABLE seat
  const event = await prisma.event.findFirst({
    include: { showSeats: { where: { status: 'AVAILABLE' } } },
  });

  if (!event || event.showSeats.length === 0) {
    throw new Error('No available seats found for testing');
  }

  const targetSeat = event.showSeats[0];
  console.log(`🎯 Target Seat: ${targetSeat.seatLabel} (ID: ${targetSeat.id}) on Event: "${event.title}"`);

  // 2. Fetch users
  const users = await prisma.user.findMany({
    where: { role: 'CUSTOMER' },
    take: 5,
  });

  if (users.length < 2) {
    throw new Error('Need at least 2 customer users for concurrency test');
  }

  console.log(`👥 Simulating ${users.length} simultaneous hold requests for seat ${targetSeat.seatLabel}...`);

  // 3. Fire simultaneous parallel requests at the exact same millisecond
  const promises = users.map((user) =>
    seatService
      .holdSeats(event.id, [targetSeat.id], user.id)
      .then((res) => ({ success: true, userId: user.id, name: user.name, res }))
      .catch((err) => ({ success: false, userId: user.id, name: user.name, statusCode: err.statusCode, message: err.message }))
  );

  const results = await Promise.all(promises);

  const successfulHolds = results.filter((r) => r.success);
  const failedHolds = results.filter((r) => !r.success);

  console.log('\n📊 Concurrency Execution Results:');
  results.forEach((r, idx) => {
    if (r.success) {
      console.log(`   ✅ Request ${idx + 1} (${r.name}): SUCCESS (200 OK) - Acquired Hold until ${r.res.expiresAt.toISOString()}`);
    } else {
      console.log(`   ❌ Request ${idx + 1} (${r.name}): REJECTED (${r.statusCode || 409} Conflict) - "${r.message}"`);
    }
  });

  // 4. Assertions
  console.log('\n🔍 Verifying Invariants:');
  if (successfulHolds.length === 1) {
    console.log('   ✅ PASS: Exactly 1 customer successfully acquired the seat hold.');
  } else {
    throw new Error(`   ❌ FAIL: Expected exactly 1 success, but got ${successfulHolds.length}`);
  }

  if (failedHolds.length === users.length - 1) {
    console.log(`   ✅ PASS: Exactly ${failedHolds.length} competing requests received 409 Conflict.`);
  } else {
    throw new Error(`   ❌ FAIL: Concurrency leak detected!`);
  }

  // Verify DB state
  const updatedSeat = await prisma.showSeat.findUnique({ where: { id: targetSeat.id } });
  if (updatedSeat.status === 'HELD' && updatedSeat.heldByUserId === successfulHolds[0].userId) {
    console.log(`   ✅ PASS: Database state verified: Status=HELD, HeldBy=${successfulHolds[0].name}`);
  } else {
    throw new Error('   ❌ FAIL: Database state mismatch');
  }

  console.log('\n🎉 Concurrency Protection Test PASSED flawlessly!\n');
}

runConcurrencyTest()
  .catch((err) => {
    console.error('❌ Test failed:', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
