import { execSync } from 'child_process';

console.log('\n======================================================');
console.log('🚀 RUNNING ALL AUTOMATED VERIFICATION SUITES');
console.log('======================================================');

const tests = [
  { name: 'Seat Hold TTL & Auto-Release', file: 'tests/seatHold.test.js' },
  { name: 'Concurrency Protection & Race-Condition Safety', file: 'tests/concurrency.test.js' },
  { name: 'Waitlist Auto-Assignment & Time-Limited Offers', file: 'tests/waitlist.test.js' },
];

let passed = 0;
let failed = 0;

for (const test of tests) {
  try {
    console.log(`\n▶️ Executing: ${test.name}...`);
    execSync(`node ${test.file}`, { stdio: 'inherit' });
    passed++;
  } catch (error) {
    console.error(`❌ Test failed: ${test.name}`);
    failed++;
  }
}

console.log('\n======================================================');
console.log(`📋 TEST RESULTS SUMMARY: ${passed} PASSED, ${failed} FAILED`);
console.log('======================================================\n');

if (failed > 0) {
  process.exit(1);
} else {
  console.log('🌟 ALL TEST SUITES COMPLETED WITH 100% SUCCESS!\n');
  process.exit(0);
}
