import React, { createContext, useContext, useEffect, useState } from 'react';
import socket from '../services/socket';
import { useAuth } from './AuthContext';

const SocketContext = createContext(null);

export const SocketProvider = ({ children }) => {
  const { user } = useAuth();
  const [activeOffer, setActiveOffer] = useState(null);
  const [isConnected, setIsConnected] = useState(socket.connected);

  useEffect(() => {
    const onConnect = () => setIsConnected(true);
    const onDisconnect = () => setIsConnected(false);

    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);

    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
    };
  }, []);

  // Join user room when authenticated
  useEffect(() => {
    if (user?.id) {
      socket.emit('join_user', user.id);

      const handleWaitlistOffer = (payload) => {
        console.log('⚡ Received real-time waitlist offer:', payload);
        setActiveOffer(payload);
      };

      socket.on('waitlist_offer_received', handleWaitlistOffer);

      return () => {
        socket.off('waitlist_offer_received', handleWaitlistOffer);
      };
    }
  }, [user]);

  const dismissOffer = () => {
    setActiveOffer(null);
  };

  return (
    <SocketContext.Provider value={{ socket, isConnected, activeOffer, dismissOffer }}>
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => useContext(SocketContext);
