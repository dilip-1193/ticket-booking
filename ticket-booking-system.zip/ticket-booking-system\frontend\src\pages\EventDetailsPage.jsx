import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Calendar, Clock, MapPin, Film, Music, Shield, ArrowRight, Sparkles } from 'lucide-react';
import api from '../services/api';
import WaitlistModal from '../components/WaitlistModal';

export const EventDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedShowtime, setSelectedShowtime] = useState('19:30');
  const [showWaitlistModal, setShowWaitlistModal] = useState(false);

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const res = await api.get(`/events/${id}`);
        if (res.data.success) {
          setEvent(res.data.event);
          if (res.data.event.showTime) {
            setSelectedShowtime(res.data.event.showTime);
          }
        }
      } catch (error) {
        console.error('Error loading event:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchEvent();
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-20 animate-pulse">
        <div className="h-80 bg-[#052053] rounded-3xl mb-8"></div>
        <div className="h-10 bg-[#052053] w-1/2 rounded-xl mb-4"></div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="text-center py-24">
        <h2 className="text-xl font-bold text-white">Event Not Found</h2>
        <Link to="/" className="text-[#044BDD] text-sm mt-4 inline-block underline">
          Return to Events
        </Link>
      </div>
    );
  }

  const showtimes = ['10:00 AM', '1:30 PM', '4:30 PM', '7:30 PM', '10:15 PM'];
  const isMovie = event.type === 'MOVIE';

  return (
    <div className="min-h-screen pb-20">
      {/* Banner / Poster Header */}
      <div className="relative w-full h-[400px] lg:h-[460px] bg-black overflow-hidden flex items-end">
        <img
          src={event.bannerUrl || event.posterUrl}
          alt={event.title}
          className="absolute inset-0 w-full h-full object-cover opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#02050A] via-[#02050A]/80 to-transparent"></div>

        <div className="relative max-w-6xl mx-auto px-4 lg:px-8 pb-10 w-full flex flex-col md:flex-row items-start md:items-end gap-6 z-10">
          <img
            src={event.posterUrl}
            alt={event.title}
            className="w-36 sm:w-48 aspect-[3/4] object-cover rounded-2xl border-2 border-[#044BDD]/40 shadow-2xl shrink-0"
          />

          <div className="space-y-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#044BDD]/20 border border-[#044BDD] text-[#5C98A7]">
              {event.genre} · {event.durationMinutes} min
            </span>

            <h1 className="text-2xl sm:text-4xl font-extrabold text-white">{event.title}</h1>

            <div className="flex flex-wrap items-center gap-4 text-xs text-[#C2D8DF] pt-1">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-[#5C98A7]" />
                <span>{new Date(event.eventDate).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#5C98A7]" />
                <span>{event.venue?.name}, {event.venue?.city}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-6xl mx-auto px-4 lg:px-8 mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Synopsis and Showtimes */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-[#052053]/40 border border-[#052053] rounded-3xl p-6">
            <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#044BDD]" /> About This Event
            </h3>
            <p className="text-sm text-[#C2D8DF] leading-relaxed">{event.description}</p>
          </div>

          {/* Showtime Selection */}
          <div className="bg-[#052053]/40 border border-[#052053] rounded-3xl p-6">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#044BDD]" /> Select Showtime
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              {showtimes.map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setSelectedShowtime(st)}
                  className={`py-3 px-2 rounded-2xl border text-xs font-bold transition-all text-center ${
                    selectedShowtime === st
                      ? 'bg-[#044BDD] border-white text-white shadow-glow-blue scale-105'
                      : 'bg-[#031435] border-[#0a2e73] text-[#8D98A7] hover:text-white hover:border-[#044BDD]'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* Seat Categories & Pricing */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-[#052053]/40 border border-[#044BDD]/40 rounded-3xl p-5 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#044BDD]/10 rounded-full blur-xl pointer-events-none"></div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#5C98A7]">Front Tier</span>
              <h4 className="text-lg font-extrabold text-white mt-1">Premium Seating</h4>
              <p className="text-xs text-[#8D98A7] mt-1 mb-4">Prime viewing angle with extra legroom & Dolby Atmos fidelity</p>
              <div className="text-2xl font-black text-white">${event.premiumPrice?.toFixed(2)}</div>
            </div>

            <div className="bg-[#052053]/40 border border-[#052053] rounded-3xl p-5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#8D98A7]">Standard Tier</span>
              <h4 className="text-lg font-extrabold text-white mt-1">Standard Seating</h4>
              <p className="text-xs text-[#8D98A7] mt-1 mb-4">Comfortable cinema seating with clear visual positioning</p>
              <div className="text-2xl font-black text-white">${event.standardPrice?.toFixed(2)}</div>
            </div>
          </div>
        </div>

        {/* Right Column: Booking Action Card */}
        <div className="space-y-6">
          <div className="bg-gradient-to-b from-[#052053] to-[#031435] border border-[#044BDD]/50 rounded-3xl p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-white mb-2">Reserve Your Experience</h3>
            <p className="text-xs text-[#8D98A7] mb-6 leading-relaxed">
              Real-time interactive seat map with 10-minute temporary seat hold and instant digital ticket delivery.
            </p>

            <div className="space-y-3 mb-6 text-xs text-[#C2D8DF] bg-[#02050A]/70 p-4 rounded-2xl border border-[#0a2e73]">
              <div className="flex justify-between">
                <span className="text-[#8D98A7]">Selected Show:</span>
                <span className="font-semibold text-white">{selectedShowtime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8D98A7]">Venue:</span>
                <span className="font-semibold text-white truncate max-w-[150px]">{event.venue?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8D98A7]">City:</span>
                <span className="font-semibold text-white">{event.venue?.city}</span>
              </div>
            </div>

            <button
              onClick={() => navigate(`/events/${event.id}/seats`)}
              className="w-full py-4 px-4 rounded-2xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-extrabold text-sm shadow-cinematic transition-all hover:scale-102 flex items-center justify-center gap-2 mb-3"
            >
              <span>Continue to Visual Seat Map</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => setShowWaitlistModal(true)}
              className="w-full py-2.5 px-4 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-all"
            >
              Join Priority Waitlist
            </button>
          </div>
        </div>
      </div>

      {/* Waitlist Modal */}
      <WaitlistModal
        event={event}
        isOpen={showWaitlistModal}
        onClose={() => setShowWaitlistModal(false)}
      />
    </div>
  );
};

export default EventDetailsPage;
