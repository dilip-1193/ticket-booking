import QRCode from 'qrcode';
import { logger } from '../utils/logger.js';

export const qrService = {
  /**
   * Generate base64 Data URL for a booking reference
   */
  async generateTicketQR(bookingReference, metadata = {}) {
    try {
      const payload = JSON.stringify({
        ref: bookingReference,
        event: metadata.eventTitle || '',
        seats: metadata.seats || [],
        user: metadata.customerName || '',
        ts: Date.now(),
      });

      const qrDataUrl = await QRCode.toDataURL(payload, {
        errorCorrectionLevel: 'H',
        type: 'image/png',
        margin: 2,
        width: 300,
        color: {
          dark: '#02050A',
          light: '#FFFFFF',
        },
      });

      return qrDataUrl;
    } catch (error) {
      logger.error('Error generating QR code:', error);
      // Fallback simple QR
      return await QRCode.toDataURL(bookingReference);
    }
  },
};
