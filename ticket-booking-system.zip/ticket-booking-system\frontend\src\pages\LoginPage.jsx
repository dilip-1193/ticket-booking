import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Film, Lock, Mail, ArrowRight, Zap, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { login, switchDemoUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const returnUrl = location.state?.returnUrl || '/';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await login(email, password);
      navigate(returnUrl);
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid email or password.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async (role) => {
    try {
      await switchDemoUser(role);
      navigate(returnUrl);
    } catch (err) {
      setError('Demo login failed.');
    }
  };

  return (
    <div className="min-h-screen py-16 px-4 flex items-center justify-center">
      <div className="max-w-md w-full bg-[#052053]/50 border border-[#052053] rounded-3xl p-8 shadow-2xl backdrop-blur-md">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#044BDD] to-[#5C98A7] flex items-center justify-center mx-auto mb-3 shadow-glow-blue">
            <Film className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-extrabold text-white">Welcome Back</h1>
          <p className="text-xs text-[#8D98A7] mt-1">Sign in to book tickets, manage holds, and view waitlists</p>
        </div>

        {/* Quick Demo Switcher Buttons */}
        <div className="mb-6 p-3 bg-[#031435] border border-[#0a2e73] rounded-2xl">
          <span className="text-[10px] uppercase font-bold text-[#8D98A7] flex items-center gap-1 mb-2">
            <Zap className="w-3 h-3 text-[#F5B942]" /> 1-Click Instant Demo Login:
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleDemoLogin('CUSTOMER_1')}
              className="py-1.5 px-2 rounded-lg bg-[#052053] hover:bg-[#044BDD] text-[11px] font-semibold text-[#C2D8DF] hover:text-white transition-colors text-center"
            >
              Customer 1
            </button>
            <button
              type="button"
              onClick={() => handleDemoLogin('CUSTOMER_2')}
              className="py-1.5 px-2 rounded-lg bg-[#052053] hover:bg-[#044BDD] text-[11px] font-semibold text-[#C2D8DF] hover:text-white transition-colors text-center"
            >
              Customer 2 (Race)
            </button>
            <button
              type="button"
              onClick={() => handleDemoLogin('ORGANISER')}
              className="py-1.5 px-2 rounded-lg bg-[#052053] hover:bg-purple-600 text-[11px] font-semibold text-purple-200 hover:text-white transition-colors text-center"
            >
              Organiser
            </button>
            <button
              type="button"
              onClick={() => handleDemoLogin('ADMIN')}
              className="py-1.5 px-2 rounded-lg bg-[#052053] hover:bg-amber-600 text-[11px] font-semibold text-amber-200 hover:text-white transition-colors text-center"
            >
              Administrator
            </button>
          </div>
        </div>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-950/70 border border-red-500/70 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-[#8D98A7] font-semibold mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-[#8D98A7] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-[#8D98A7] focus:outline-none focus:border-[#044BDD]"
              />
            </div>
          </div>

          <div>
            <label className="block text-[#8D98A7] font-semibold mb-1.5">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#8D98A7] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#02050A] border border-[#0a2e73] rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-[#8D98A7] focus:outline-none focus:border-[#044BDD]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-4 rounded-2xl bg-[#044BDD] hover:bg-[#0337A0] text-white font-extrabold text-sm shadow-cinematic transition-all hover:scale-102 disabled:opacity-50 mt-2 flex items-center justify-center gap-2"
          >
            <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <p className="text-center text-xs text-[#8D98A7] mt-6">
          Don't have an account?{' '}
          <Link to="/register" className="text-[#044BDD] hover:underline font-semibold">
            Create an Account
          </Link>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
